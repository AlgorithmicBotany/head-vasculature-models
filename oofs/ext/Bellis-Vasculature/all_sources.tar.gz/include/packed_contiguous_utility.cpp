#include "packed_contiguous_utility.h"

#include <iostream>

namespace utility {

std::ostream &operator<<(std::ostream &out, index_interval const &range) {
  return out << range.first << ' ' << range.second;
}

std::istream &operator>>(std::istream &in, index_interval &range) {
  return in >> range.first >> range.second;
}

} // namespace utility
