#pragma once

#include <cstdint>
#include <iosfwd>

#include "vec3f.h"

namespace math {

struct Vec3i {
  union {
    struct {
      int32_t x;
      int32_t y;
      int32_t z;
    };
    //    float m_coord[3] = {0.f, 0.f, 0.f}; // TODO: clang seems to force
    //    this?
    int32_t m_coord[3];
  };

  // Vec3i() = default; // TODO: clang issue from above
  Vec3i();

  Vec3i(int32_t x, int32_t y, int32_t z);

  Vec3i &operator+=(Vec3i const &rhs);

  Vec3i &operator-=(Vec3i const &rhs);

  Vec3i &operator*=(int32_t rhs);

  Vec3i &operator/=(int32_t rhs);

  int32_t &operator[](size_t id);

  int32_t const &operator[](size_t id) const;

  int32_t *data();

  int32_t const *data() const;

  void zero();
};

// Free function
/*
 * Vector-Vector Addition/ Subtraction
 */
Vec3i operator+(Vec3i const &a, Vec3i const &b);
Vec3i operator-(Vec3i const &a, Vec3i const &b);

/*
 * Scalar-Vector Multiplication/Division
 */
Vec3i operator*(int32_t s, Vec3i v);
Vec3i operator*(Vec3i v, int32_t s);

Vec3i operator/(Vec3i v, int32_t s);

/*
 * Negation of vector
 * -v = (-1.f) * v
 */
Vec3i operator-(Vec3i v);

/*
 * Vector-Vector (inner/dot) product
 */
float operator*(Vec3i const &a, Vec3i const &b);
float dot(Vec3i const &a, Vec3i const &b);

/*
 * Vector norm (length)
 */
float norm(Vec3i const &v);
float normSquared(Vec3i const &v);

/*
 * Linear int32_terpolation
 */
Vec3i lerp(Vec3i const &a, Vec3i const &b, float t);

float distance(Vec3i const &a, Vec3i const &b);

float distanceSquared(Vec3i const &a, Vec3i const &b);

Vec3i componentMultiplication(const Vec3i &lhs, const Vec3i &rhs);

std::ostream &operator<<(std::ostream &out, Vec3i const &v);

std::istream &operator>>(std::istream &in, Vec3i &v);

} // namespace math
