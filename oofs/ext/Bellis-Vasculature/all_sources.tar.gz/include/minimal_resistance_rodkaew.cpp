#include "minimal_resistance_rodkaew.h"

#include <iostream>
#include <map>
#include <queue>
#include <unordered_set>

#include "containers_utility.h"
#include "geometry_utility.h"
#include "math_utility.h"
#include "random_utility.h"

#include "solid_angle_clustering.h"

namespace vasculature {

using MinRes = MinimalResistanceRodkaew;

void stepVascularAge(MinRes::Vasculature &veins, float r_groundTissue,
                     float r_vascular, int ageFullyGrown) {
  for (auto node : veins) {
    node->data.age++;

    node->data.resistanceAtNode =
        node->data.baseResistance *
        math::lerp(r_groundTissue, 1.f,
                   math::smoothstep(node->data.age, 0.f, ageFullyGrown));
  }
}

void acropetal_recalculateVascularResistances(
    MinRes::Vasculature &veins, MinRes::Vasculature::node_refs const &sinks) {
  for (auto sink : sinks) {
    sink->data.effectiveResistance = 0.f;
    // dbg
    sink->data.distanceToBase = 0.f;

    std::queue<MinRes::Vasculature::node_ptr> nodesToSee;
    nodesToSee.push(sink);

    while (!nodesToSee.empty()) {
      auto node = nodesToSee.front();
      nodesToSee.pop();

      for (auto child : node->children()) {
        auto dist = distance(node->data.position, child->data.position);

        child->data.effectiveResistance =
            child->data.resistanceAtNode * dist +
            node->data.effectiveResistance; // resistance to base

        // dbg
        child->data.distanceToBase = dist + node->data.distanceToBase;

        nodesToSee.push(child);
      }
    }
  }
}

MinRes::Vasculature::node_refs
selectSolidAngleVisibleAround(math::Vec3f const &p,
                              MinRes::Vasculature const &veins,
                              float shieldingSolidAngle) {
  std::vector<math::Vec3f> points;
  points.reserve(veins.size());

  for (auto node : veins) {
    if (node->data.effectiveResistance < 9999.f)
      points.push_back(node->data.position);
  }

  auto selected = clustering::selectSolidAngleClusterAround(
      p, points, shieldingSolidAngle, 2.f * M_PI);
  // clustering::selectSolidAngleClusterAround(p, points, 1.4f, 0.75f * M_PI);
  // clustering::selectSolidAngleClusterAround(p, points, 0.49f, 0.75f * M_PI);

  MinRes::Vasculature::node_refs considered;
  int id = 0;
  for (; id < selected.size(); ++id) {
    auto pos = selected[id].p * selected[id].w + p;
    float closestDist = 99999.f;
    MinRes::Vasculature::node_ptr closest;
    for (auto node : veins) {
      auto dist = distance(node->data.position, pos);
      if (dist < closestDist) {
        closestDist = dist;
        closest = node;
      }
    }
    considered.push_back(closest);
  }
  return considered;
}

struct ResistanceMinimizer {
  MinRes::Vasculature::node_ptr node{nullptr};
  float R; // effective resistance
  float d; // distance

  operator bool() const { return node != nullptr; };
};

ResistanceMinimizer findResistanceMinimizer(MinRes::Vasculature::node_ptr tip,
                                            MinRes::Vasculature const &veins,
                                            float r_groundTissue,
                                            float mergeDistance,
                                            float sectorialPropensity,
                                            float shieldingSolidAngle) {

  auto visible = selectSolidAngleVisibleAround(tip->data.position, veins,
                                               shieldingSolidAngle);

  ResistanceMinimizer rMin;
  rMin.R = math::maxValue<float>();
  rMin.node = nullptr;

  // dbg
  // std::cout << "SELECTED " << visible.size() << std::endl;
  // tip->data.oldestNeighs.clear();

  float maxAge = 0.f;
  for (auto node : visible) {
    // tip->data.oldestNeighs.push_back(&(node->data));
    if (node->data.age > maxAge) {
      maxAge = node->data.age;
    }
  }

  // for (auto node : veins) {
  for (auto node : visible) {
    if (node->data.effectiveResistance >= tip->data.effectiveResistance)
      continue;

    auto d = distance(tip->data.position, node->data.position);

    if (d < mergeDistance) {
      rMin.node = node;
      rMin.d = d;
      return rMin;
    }

    // auto resistanceTissue = r_groundTissue + node->data.resistanceAtNode;
    auto resistanceTissue = r_groundTissue + 1.f * (maxAge / node->data.age);
    // node->data.resistanceAtNode;
    // auto resistanceTissue = r_groundTissue;

    if (sectorialPropensity > 0.f)
      resistanceTissue *= sectorialResistivityFactor(
          tip->data.position, node->data.position, sectorialPropensity);

    auto resistanceThroughTissue = resistanceTissue * d;
    auto resistanceThroughVeins = node->data.effectiveResistance;

    auto effectiveResistance =
        resistanceThroughTissue + 1.f * resistanceThroughVeins;

    if (effectiveResistance < rMin.R) {
      rMin.R = effectiveResistance;
      rMin.node = node;

      rMin.d = d;
    }
  }

  return rMin;
}

ResistanceMinimizer findClosestViable(MinRes::Vasculature::node_ptr tip,
                                      MinRes::Vasculature const &veins,
                                      float mergeDistance) {
  ResistanceMinimizer rMin;
  rMin.R = math::maxValue<float>();

  for (auto node : veins) {
    if (node->data.effectiveResistance >= tip->data.effectiveResistance)
      continue;

    auto d = distance(tip->data.position, node->data.position);

    if (d < mergeDistance) {
      rMin.node = node;
      rMin.d = d;
      return rMin;
    }
  }

  return rMin;
}

MinRes::Vasculature::node_ptr growVeinInitialOrthogonalToReceptical(
    MinRes::Vasculature::node_ptr tip, MinRes::Vasculature &veins,
    float stepDistance, float veinJitterStrength, float veinJitterFrequency) {

  auto distanceInto = norm(tip->data.direction);

  auto orthoDirection = tip->data.direction;
  orthoDirection /= distanceInto;

  auto dist{0.f};
  while (dist < distanceInto) {
    dist += stepDistance;
    auto newTip = veins.addNode();

    auto dir = orthoDirection;

    // Feature: randomize
    if (veinJitterStrength > 0.f && veinJitterFrequency > 0.f) {
      auto random = randutil::uniformSphere();
      random = math::orthogonalize(random, dir);
      if (randutil::uniform(0.f, 1.f) < veinJitterFrequency)
        dir += random * veinJitterStrength;
    }

    newTip->adopt(tip); // extend

    newTip->data.position = tip->data.position + dir * stepDistance;
    newTip->data.age = 0.f;
    newTip->data.direction = tip->data.direction;
    newTip->data.resistanceAtNode = tip->data.resistanceAtNode;
    newTip->data.baseResistance = tip->data.baseResistance;
    newTip->data.effectiveResistance = math::maxValue<float>();
    newTip->data.type = tip->data.type;

    tip = newTip;
  }

  return tip;
}

bool growMinimalResistanceVein(MinRes::Vasculature &veins,
                               MinRes::Vasculature::node_ptr tip,
                               float r_groundTissue, float mergeDistance,
                               float stepDistance, float veinJitterFrequency,
                               float veinJitterStrength,
                               float sectorialPropensity,
                               float shieldingSolidAngle) {

  auto rMinInit =
      findResistanceMinimizer(tip, veins, r_groundTissue, mergeDistance,
                              sectorialPropensity, shieldingSolidAngle);
  if (!rMinInit)
    return false;

  // tip->data.oldestNeighs.clear();
  // if (rMinInit)
  //  tip->data.oldestNeighs.push_back(&(rMinInit.node->data));

  int iter = 0;
  while (iter++ < 500) {

    auto speed = norm(tip->data.direction);
    if (speed > 1.f) {
      tip->data.direction = 0.1f * tip->data.direction;
    }

    // incrementally extend vasculature to minimizers
    auto rMin = findClosestViable(tip, veins, mergeDistance);

    if (rMin) {
      if (rMin.d <= mergeDistance) {

        // DBG
        if (rMin.node->hasParents())
          rMin.node = rMin.node->parents()[0];

        rMin.node->adopt(tip);
        return true;
      }
    }

    auto direction =
        math::normalized(rMinInit.node->data.position - tip->data.position) +
        tip->data.direction;
    // direction += tip->data.direction;
    // direction += norm(tip->data.direction) * direction;
    tip->data.direction = norm(tip->data.direction) * direction;

    // Feature: randomize
    if (veinJitterStrength > 0.f && veinJitterFrequency > 0.f) {
      auto random = randutil::uniformSphere();
      random = math::orthogonalize(random, direction);
      if (randutil::uniform(0.f, 1.f) < veinJitterFrequency)
        direction += random * veinJitterStrength;
    }

    // direction.normalize();

    auto newTip = veins.addNode();

    newTip->adopt(tip); // extend

    newTip->data.position = tip->data.position + direction * stepDistance;
    newTip->data.age = 0.f;
    newTip->data.direction = tip->data.direction;
    newTip->data.resistanceAtNode = tip->data.resistanceAtNode;
    newTip->data.baseResistance = tip->data.baseResistance;
    newTip->data.effectiveResistance = math::maxValue<float>();
    newTip->data.type = tip->data.type;

    tip = newTip;
  }

  return true;
}

void growMinimalResistancePathVeins(
    MinRes::Vasculature &veins, MinRes::Vasculature::node_refs const &veinTips,
    float r_groundTissue, float mergeDistance, float stepDistance,
    float veinJitterFrequency, float veinJitterStrength,
    float sectorialPropensity, float shieldingSolidAngle) {
  for (auto tip : veinTips) {

    growMinimalResistanceVein(veins, tip, r_groundTissue, mergeDistance,
                              stepDistance, veinJitterFrequency,
                              veinJitterStrength, sectorialPropensity,
                              shieldingSolidAngle);
  }
}

using NodeID = int;
using DistantNodeID = geometry::Distant<NodeID>;
DistantNodeID findClosestNodeIDTo(math::Vec3f const &p,
                                  MinRes::Vasculature const &veins) {
  DistantNodeID closest;
  closest.distance = math::maxValue<float>();

  for (int nID = 0; nID < veins.size(); ++nID) {
    auto node = veins[nID];
    if (node->data.age < 0)
      continue;

    // TODO used to ignore floret veins!
    if (node->data.type == MinRes::NodeType::FLORET)
      continue;

    auto dist = distance(p, node->data.position);
    if (dist < closest.distance) {
      closest.distance = dist;
      closest.data = nID;
    }
  }

  return closest;
}

MinRes::Vasculature::node_refs
growDiffuseVeins(MinRes::Vasculature &veins,
                 MinRes::DiffuseAuxinPoints &diffuseAuxin, float r_groundTissue,
                 float mergeDistance, float stepDistance,
                 float veinJitterFrequency, float veinJitterStrength,
                 float sectorialPropensity, float killDistance) {
  MinRes::Vasculature::node_refs newTips;

  if (veins.empty() || diffuseAuxin.empty())
    return newTips;

  using DistantPoint = geometry::Distant<math::Vec3f>;
  using NodeID = int;
  // map of vein nodes to auxin points that selected that node
  std::map<NodeID, std::vector<DistantPoint>> selected;

  for (int aID = 0; aID < diffuseAuxin.size(); ++aID) {
    auto const &auxinPoint = diffuseAuxin[aID];

    auto closestNode = findClosestNodeIDTo(auxinPoint, veins);

    // add auxin point to selected
    if (closestNode.distance > killDistance) {
      selected[closestNode.data].push_back({auxinPoint, closestNode.distance});
    } else {
      // kill auxin point
      utility::swap_pop(diffuseAuxin, aID--);
    }
  }

  for (auto const &select : selected) {
    auto node = veins[select.first];
    auto const &auxinPoints = select.second;

    math::Vec3f direction{};

    for (auto const &auxinPoint : auxinPoints) {
      direction += (auxinPoint.data - node->data.position) /
                   auxinPoint.distance; // normalized dir
    }

    direction.normalize();

    if (veinJitterStrength > 0.f && veinJitterFrequency > 0.f) {
      auto random = randutil::uniformSphere();
      random = math::orthogonalize(random, direction);
      if (randutil::uniform(0.f, 1.f) < veinJitterFrequency)
        direction += random * veinJitterStrength;
    }

    // extend node in direction
    auto tipPosition = node->data.position + direction * stepDistance;

    auto tip = veins.addNode();
    tip->data.position = tipPosition;
    tip->data.direction = node->data.direction;
    tip->data.age = 0;
    tip->data.type = node->data.type;

    node->adopt(tip);

    newTips.push_back(tip);
  }

  return newTips;
}

//
// Features
//

float sectorialResistivityFactor(math::Vec3f const &tip,
                                 math::Vec3f const &point,
                                 float sectorialPropensity) {
  using namespace math;
  auto r = zeroY(tip);
  auto len = norm(r);

  if (len <= 1e-5f)
    return 1.f;

  r /= len;
  auto ortho = cross(axis3::Y, r);

  if (norm(ortho) <= 1e-5f)
    return 1.f;

  auto dir = normalized(point - tip);
  auto alignment = ortho * dir;
  auto factor = 1.f + sectorialPropensity * (alignment * alignment);

  return factor * factor * factor * factor;
  // return factor * factor;
}

MinRes::Vasculature::node_refs
calculateRelative(MinRes::Vasculature::node_ptr node,
                  MinRes::Vasculature::node_refs const &nodes) {

  MinRes::Vasculature::node_refs tmps;
  auto const &position = node->data.position;

  for (int i = 0; i < nodes.size(); ++i) {
    auto node_i = nodes[i];

    if (node_i == node)
      continue;

    auto s_i = distance(position, node_i->data.position);

    if (s_i < 1e-5)
      continue;

    bool isRelative = true;

    for (int j = 0; j < nodes.size(); ++j) {
      if (j == i)
        continue;

      auto node_j = nodes[j];

      if (node_j == node)
        continue;

      auto s_j = distance(position, node_j->data.position);

      if (s_j < 1e-5)
        continue;

      auto i_j = distance(node_i->data.position, node_j->data.position);

      if (s_i - std::max(s_j, i_j) > 0.f) {
        isRelative = false;
        break;
      }
    }

    // is a relative
    if (isRelative)
      tmps.push_back(node_i);
  }

  return tmps;
}

MinRes::Vasculature::node_refs processReticulateNodes(
    MinRes::Vasculature &veins,
    MinRes::Vasculature::node_refs &reticulateNodesToBeProcessed,
    MinRes::Vasculature::node_refs &reticulateNodes, float mergeDistance,
    float stepDistance, float veinJitterFrequency, float veinJitterStrength,
    float sectorialPropensity, float reticulationPropensity, float r_ground,
    int reticulationAgeTrigger) {

  float delay = reticulationAgeTrigger;
  // float splitDist = randutil::uniform(0.01, 0.05f);
  // traverse down dist (maybe should be min resistance)

  MinRes::Vasculature::node_refs newNodes;

  for (int i = 0; i < reticulateNodesToBeProcessed.size(); ++i) {
    auto node = reticulateNodesToBeProcessed[i];
    if (node->data.age < delay)
      continue;

    auto polarizationIntoHead = norm(node->data.direction);
    float splitDist = polarizationIntoHead * randutil::uniform(1.05f, 1.1f);
    auto dist{0.f};
    // if (node->data.type == MinRes::NodeType::FLORET) {
    //  while (node->hasParents() &&
    //         node->data.type == MinRes::NodeType::FLORET) {
    //    node = node->parents()[0];
    //  }
    //}

    while (node->hasParents() && dist <= splitDist) {
      auto parent = node->parents()[0];
      dist += distance(parent->data.position, node->data.position);
      node = parent;
    }

    // remove and decrement
    utility::swap_pop(reticulateNodesToBeProcessed, i--);

    // Feature:
    // -relative neighbours from among the reticulation points
    // auto relativeNeigh = calculateRelative(node, reticulateNodes);
    auto relativeNeigh = reticulateNodes;
    std::sort(
        std::begin(relativeNeigh), std::end(relativeNeigh),
        // c++17 [=](auto a, auto b) {
        [=](MinRes::Vasculature::node_ptr a, MinRes::Vasculature::node_ptr b) {
          auto da = distance(node->data.position, a->data.position);
          auto db = distance(node->data.position, b->data.position);

          auto sectorialA = sectorialResistivityFactor(
              node->data.position, a->data.position, sectorialPropensity);
          auto sectorialB = sectorialResistivityFactor(
              node->data.position, b->data.position, sectorialPropensity);
          da *= sectorialA;
          db *= sectorialB;
          return da < db;
        });

    int id = 0;
    for (; id < 3 && id < relativeNeigh.size(); ++id) {
      if (distance(node->data.position, relativeNeigh[id]->data.position) >
          0.7f)
        break;
      // node->data.closestNeighs.push_back(&(relativeNeigh[id]->data));
    }
    relativeNeigh.resize(std::min(id, 3));

    std::queue<MinRes::Vasculature::node_ptr> front;
    std::unordered_set<MinRes::Vasculature::node_ptr> visited;

    // diffuse out to see connectivity?
    // or check EffRes
    front.push(node);
    bool found = false;
    while (!front.empty()) {
      auto next = front.front();
      front.pop();

      for (int j = 0; j < relativeNeigh.size(); ++j) {
        auto neigh = relativeNeigh[j];
        if (neigh == next) //
        {
          found = true;
          utility::swap_pop(relativeNeigh, j--);
          break;
        }
      }

      if (found) // next should be excluded
      {
        break;
      }

      for (auto parent : next->parents()) {
        if (visited.find(parent) != visited.end())
          continue;

        front.push(parent);
      }
      for (auto child : next->children()) {
        if (visited.find(child) != visited.end())
          continue;

        front.push(child);
      }

      visited.insert(next);
    }

    std::sort(
        std::begin(relativeNeigh), std::end(relativeNeigh),
        // c++17 [](auto a, auto b)
        [](MinRes::Vasculature::node_ptr a, MinRes::Vasculature::node_ptr b) {
          return a->data.age > b->data.age;
        });
    relativeNeigh.resize(std::min(1, int(relativeNeigh.size())));

    // grow to relative neighs
    for (auto neigh : relativeNeigh) {

      if (randutil::uniform(0.f, 1.f) > reticulationPropensity)
        continue;

      auto dist = distance(neigh->data.position, node->data.position);
      if (dist > 0.5f)
        continue;

      auto effRes = node->data.effectiveResistance;
      auto alternativeER = dist * (r_ground + neigh->data.resistanceAtNode) +
                           neigh->data.effectiveResistance;

      if (effRes - alternativeER < -3.3f)
        continue;

      // if (distance(neigh->data.position, node->data.position) > 0.5f)
      //  continue;

      // int count = 0;
      // while (neigh->hasParents() && count++ < 6 &&
      //       neigh->children().size() < 2) {
      //  neigh = neigh->parents()[0];
      //}
      // count = 0;
      // while (node->hasParents() && count++ < 5) {
      //  node = node->parents()[0];
      //}

      auto close = neigh;
      auto leastDistance = distance(close->data.position, node->data.position);

      // MinRes::Vasculature::node_ptr midClose{nullptr};
      // int step = 0;

      while (true) {
        auto n = node->data.position;
        auto t = neigh->data.position;

        if (distance(n, t) <= mergeDistance)
          break;

        bool merged{false};
        auto dClose = distance(close->data.position, neigh->data.position);
        if (dClose >= leastDistance * 0.4) {
          for (auto other : veins) {
            if (other->data.effectiveResistance <=
                neigh->data.effectiveResistance)
              continue;

            auto d = distance(other->data.position, neigh->data.position);
            if (d < mergeDistance) {
              // neigh->adopt(other); // extend
              merged = true;
              break;
            }
          }
        }
        if (merged)
          break;

        auto direction = normalized(n - t);

        if (veinJitterStrength > 0.f && veinJitterFrequency > 0.f) {
          auto random = randutil::uniformSphere();
          random = math::orthogonalize(random, direction);
          if (randutil::uniform(0.f, 1.f) < veinJitterFrequency)
            direction += random * veinJitterStrength;
        }

        direction.normalize();

        auto newNode = veins.addNode();

        neigh->adopt(newNode); // extend

        newNode->data.position =
            neigh->data.position + direction * stepDistance;
        newNode->data.age = neigh->data.age;
        newNode->data.direction = neigh->data.direction;
        newNode->data.type = node->data.type;
        newNode->data.resistanceAtNode = neigh->data.resistanceAtNode;
        newNode->data.effectiveResistance = neigh->data.effectiveResistance;
        newNode->data.baseResistance = neigh->data.baseResistance;

        // step++;

        neigh = newNode;
      }
      newNodes.push_back(neigh);

      neigh->data.closestNeighs.push_back(&(node->data));

      /* int findMid = 0;
       midClose = neigh;
       while (findMid < std::ceil(step * 0.5f)) {
         midClose = midClose->parents()[0];
         findMid++;
       }
       if (midClose != close)
         reticulateNodes.push_back(midClose);*/
    }
    reticulateNodes.push_back(node);
  }
  return newNodes;
}

} // namespace vasculature
