#pragma once

//
// LPFG Draw utility
// inlined helper draw functions for lpfg using custom types
// A bit cumbersome to make a .cpp/.h file since #include <lpfgall.h>
// is needed, so this is a compromise.
//
// USE:
// #include <lpfgall.h>
// #include "lpfg_draw_utility.h
//
// may not be ideal, but keeps the lsystem.l clean(er).
//

#include <cmath>

#define MoveToV3(p) MoveTo(p.x, p.y, p.z)
#define MoveToV2(p) MoveTo(p.x, p.y, 0.f)
#define LineToV3(p) LineTo(p.x, p.y, p.z)
#define LineToV2(p) LineTo(p.x, p.y, 0.f)

void MoveToVec(math::Vec3f const &p) { nproduce MoveToV3(p); }
void MoveToVec(math::Vec2f const &p) { nproduce MoveToV2(p); }

void LineToVec(math::Vec3f const &p) { nproduce LineToV3(p); }
void LineToVec(math::Vec2f const &p) { nproduce LineToV2(p); }

template <class Vec> void drawLine(Vec const &a, Vec const &b) {
  MoveToVec(a);
  LineToVec(b);
}

template <class Vec> void drawCurve(std::vector<Vec> const &vec) {
  if (vec.empty())
    return;

  MoveToVec(vec.front());
  for (int i = 1; i < vec.size(); ++i)
    LineToVec(vec[i]);
}
template <class Curve> void drawCurve(Curve const &curve) {
  drawCurve(curve.points());
}

template <class Vec> void drawCurve_GC(std::vector<Vec> const &vec) {
  if (vec.size() < 2)
    return;

  auto a = vec[0];
  auto b = vec[1];
  auto dir = math::normalized(b - a);
  auto head = V3f(dir.x, dir.y, 0.f);

  nproduce SB() MoveToV2(a) SetHead(0.f, 1.f, 0, 0.f, 0.f, 1.f) SetHead3f(head)
      StartGC();
  for (int i = 1; i < vec.size(); ++i) {
    a = vec[i - 1];
    b = vec[i];
    dir = math::normalized(b - a);
    head = V3f(dir.x, dir.y, 0.f);
    nproduce SetHead(head.x, head.y, head.z, 0.f, 0.f, 1.f) LineToV2(b)
        PointGC();
  }
  nproduce EndGC() EB();
}
template <class Curve> void drawCurve_GC(Curve const &curve) {
  drawCurve_GC(curve.points());
}

template <class Vec> void drawSphere(Vec const &p, float radius = 1.f) {
  MoveToVec(p);
  nproduce Sphere(radius);
}

template <class Vec>
void drawAngleBetween(Vec a, Vec b, Vec const &origin, float dTheta) {
  a = normalized(a);
  b = normalized(b);
  auto n = cross(a, b);
  float angleBeteen = math::angleBetween(a, b);
  MoveToVec(a + origin);
  for (float theta = 0; theta <= angleBeteen; theta += dTheta) {
    auto v = math::rotateAroundAxis(a, n, math::radianToDegree(theta));
    LineToVec(v + origin);
  }
  LineToVec(b + origin);
}

template <class Vec>
void drawTriangleOutline(Vec const &a, Vec const &b, Vec const &c) {
  MoveToVec(a);
  LineToVec(b);
  LineToVec(c);
  LineToVec(a);
}

template <class Vec>
void drawTriangle(Vec const &a, Vec const &b, Vec const &c, uint8_t colorA,
                  uint8_t colorB, uint8_t colorC) {
  MoveToVec(a);
  nproduce SP() SetColor(colorB);
  LineToVec(b);

  nproduce PP() SetColor(colorC);
  LineToVec(c);

  nproduce PP() SetColor(colorA);
  LineToVec(a);

  nproduce EP();
}

template <class TriMesh> void drawMesh_Lines(TriMesh const &mesh) {
  auto const &verts = mesh.vertices();
  auto const &faces = mesh.triangles();
  for (auto const &face : faces) {
    auto const &a = verts[face.a];
    auto const &b = verts[face.b];
    auto const &c = verts[face.c];

    drawTriangleOutline(a, b, c);
  }
}

template <class TriMesh>
void drawMesh(TriMesh const &mesh, std::vector<uint8_t> const &vertexColorIDs) {
  auto const &verts = mesh.vertices();
  auto const &faces = mesh.triangles();
  for (auto const &face : faces) {
    auto const &a = verts[face.a];
    auto const &b = verts[face.b];
    auto const &c = verts[face.c];

    auto colorA = vertexColorIDs[face.a];
    auto colorB = vertexColorIDs[face.b];
    auto colorC = vertexColorIDs[face.c];

    drawTriangle(a, b, c, colorA, colorB, colorC);
  }
}

template <class TriMesh, class ColorIDFunc>
void drawMesh(TriMesh const &mesh, std::vector<float> const &field,
              ColorIDFunc mapScalar) {
  auto const &verts = mesh.vertices();
  auto const &faces = mesh.triangles();
  for (auto const &face : faces) {
    auto const &a = verts[face.a];
    auto const &b = verts[face.b];
    auto const &c = verts[face.c];

    auto colorA = mapScalar(field[face.a]);
    auto colorB = mapScalar(field[face.b]);
    auto colorC = mapScalar(field[face.c]);

    drawTriangle(a, b, c, colorA, colorB, colorC);
  }
}

template <class Vec>
void drawDashed(std::vector<Vec> const &samples, bool even = true) {
  int drawEvery = even ? 0 : 1;
  MoveToVec(samples.front());
  for (int i = 0; i < samples.size(); ++i) {
    auto const &p = samples[i];
    if (i % 2 == drawEvery)
      LineToVec(p);
    else
      MoveToVec(p);
  }
}

void drawDashedCurve(geometry::Curve2f const &curve, float dashLength) {
  using namespace geometry;

  // draw dashed
  auto sampled = arclengthSample(subdivide(curve, 5), dashLength);
  drawDashed(sampled);
}

void drawMirroredDashedCurve(geometry::Curve2f const &curve, float dashLength) {
  using namespace geometry;

  // draw dashed
  auto sampled = arclengthSample(subdivide(curve, 5), dashLength);
  drawDashed(sampled);

  // reflect
  for (auto &p : sampled)
    p.x *= -1.f;

  drawDashed(sampled, false);
}
