/**
 * @author	Andrew Robert Owens, Philmo Gu
 * @date 	2019-10-15.
 * @details Organization: Biological Modeling and Visualization research group
 * University of Calgary, Calgary, AB, Canada
 *
 * Contact:	arowens [at] ucalgary.ca
 * @copyright Copyright (c) 2019 ___ALGORITHMIC_BOTANY___. All rights reserved.
 *
 * @brief
 */

#pragma once

#include <array>
#include <initializer_list>
#include <iosfwd>

#include "vec3f.h"

namespace math {

class Mat3f {
public:
  enum { DIMENSION = 3, NUMBER_ELEMENTS = 9 };

  using array9f = std::array<float, NUMBER_ELEMENTS>;
  using iterator = array9f::iterator;
  using const_iterator = array9f::const_iterator;

public:
  Mat3f() = default;
  explicit Mat3f(float fillValue);
  explicit Mat3f(array9f values);
  Mat3f(std::initializer_list<float> list);

  void fill(float t);

  float &operator()(int row, int column);
  float &operator[](int element);
  float &at(int row, int column);
  float &at(int element);
  float *data();

  float operator()(int row, int column) const;
  float operator[](int element) const;
  float at(int row, int column) const;
  float at(int element) const;
  float const *data() const;

  iterator begin();
  iterator end();
  const_iterator begin() const;
  const_iterator end() const;

  static int rowMajorIndex(int row, int column);

private:
  array9f m_values;
};

namespace mat3f {
Mat3f identity();
Mat3f diagonal(float x00, float x11, float x22);
Mat3f diagonal(float x);
Mat3f fromColumns(math::Vec3f const &c0, math::Vec3f const &c1,
                  math::Vec3f const &c2);
} // namespace mat3f

Mat3f operator+(Mat3f const &lhs, Mat3f const &rhs);
Mat3f operator-(Mat3f const &lhs, Mat3f const &rhs);
Mat3f operator*(Mat3f const &lhs, Mat3f const &rhs);

Mat3f operator*(float s, Mat3f rhs);
Mat3f operator*(Mat3f lhs, float s);

Mat3f transposed(Mat3f m);
float determinant(Mat3f const &m);
Mat3f inverse(Mat3f const &m);

// A' = P * A * P^-1
Mat3f leftConjugate(Mat3f const &A, Mat3f const &P);
// A' = P^-1 * A * P
Mat3f rightConjugate(Mat3f const &A, Mat3f const &P);

Vec3f operator*(Mat3f const &lhs, Vec3f const &rhs);

std::ostream &operator<<(std::ostream &out, Mat3f const &mat);

void printMatrix(math::Mat3f const &m);

} // namespace math
