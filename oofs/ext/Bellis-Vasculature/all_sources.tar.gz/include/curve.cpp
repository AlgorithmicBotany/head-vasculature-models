#include "curve.h"

namespace geometry {

Curve2f mirrorContourHorizontally(Curve2f const &curve) {
  auto points = curve.points();
  points.reserve(2 * points.size());

  for (uint32_t index = points.size() - 2; index != 0; --index) {
    auto p = points[index];
    p.x *= -1.f;
    points.push_back(p);
  }

  return Curve2f(points);
}

Curve3f mirrorContourOnYZPlane(Curve3f const &curve) {
  auto points = curve.points();
  points.reserve(2 * points.size());

  for (uint32_t index = points.size() - 2; index != 0; --index) {
    auto p = points[index];
    p.x *= -1.f;
    points.push_back(p);
  }

  return Curve3f(points);
}

Curve2f offsetContour(Curve2f const &curve, float offset) {
  Curve2f::point_store points;
  points.reserve(curve.size());

  points.push_back(curve.front() + math::Vec2f(0.f, offset));
  for (uint32_t index = 1; index < curve.size() - 1; ++index) {
    auto a = curve[index - 1];
    auto b = curve[index];
    auto c = curve[index + 1];

    auto ab = b - a;
    auto bc = c - b;

    ab = perpendicularTo(ab);
    ab.normalize();

    bc = perpendicularTo(bc);
    bc.normalize();

    auto dir = normalized(ab + bc);
    points.push_back(b + offset * dir);
  }
  points.push_back(curve.back() + math::Vec2f(0.f, -offset));

  return Curve2f(points);
}

Curve2f sampleLine(math::Vec2f a, math::Vec2f b, uint32_t sampleCount) {
  Curve2f::point_store samples;
  samples.reserve(sampleCount);

  float dt = 1.f / sampleCount;

  for (float t = 0.f; t <= 1.f; t += dt) {
    samples.push_back(math::lerp(a, b, t));
  }

  return Curve2f(samples);
}

Curve3f make3D(Curve2f const &curve) {
  Curve3f::point_store points;
  points.reserve(curve.size());

  for (auto const &p : curve) {
    points.push_back(math::Vec3f(p.x, p.y, 0.f));
  }
  return Curve3f(points);
}

} // namespace geometry
