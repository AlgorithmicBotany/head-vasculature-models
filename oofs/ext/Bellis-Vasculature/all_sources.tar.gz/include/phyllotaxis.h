#pragma once

#include <vector>

#include "vec3f.h"

namespace modelling {
namespace phyllotaxis {
constexpr double const GoldenAngle = 137.5077640500378546463487;

std::vector<math::Vec3f> spiral(uint32_t count, float primordiaRadii = 1.f);
std::vector<math::Vec3f> cylinder(uint32_t count, float cylinderRadius,
                                  float primordiaRadii = 1.f);
std::vector<math::Vec3f> unwrappedCylinder(uint32_t count, float cylinderRadius,
                                           float primordiaRadii = 1.f);

} // namespace phyllotaxis
} // namespace modelling
