#pragma once

#include <iosfwd>
#include <string>
#include <vector>

namespace modelling {
namespace phyllotaxis {

struct TimestampPrimordia {

  enum class Type : int { FLORET = 0, BRACT };

  int id{-1};       // index (ordered by patterning)
  int timestamp{0}; // when introduced (or point of significance)

  // coordinates on receptacle
  float fraction{0.f};
  float angle{0.f};

  // radius of primordia (at this time)
  float radius{0.f};

  Type type{Type::FLORET};
};

std::vector<TimestampPrimordia> gatherTimestampPrimordiaBetween(
    uint32_t timeA, uint32_t b,
    std::vector<TimestampPrimordia> const &primordia);

std::istream &operator>>(std::istream &in, TimestampPrimordia &t);
std::istream &operator>>(std::istream &in, TimestampPrimordia::Type &t);

std::ostream &operator<<(std::ostream &out, TimestampPrimordia const &t);

std::vector<TimestampPrimordia>
readTimestampPrimordiaFromFile(std::string const &filepath);

std::vector<TimestampPrimordia>
fixOutOfOrder(std::vector<TimestampPrimordia> prims); 

} // namespace phyllotaxis
} // namespace modelling
