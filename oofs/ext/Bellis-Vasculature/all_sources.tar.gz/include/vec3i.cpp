#include "vec3i.h"

#include <cmath>
#include <iostream>

namespace math {

// Member function int32_terface
// TODO added to appese clang: initialized {0,0,0} bug
Vec3i::Vec3i() : x(0), y(0), z(0) {}

Vec3i::Vec3i(int32_t x, int32_t y, int32_t z) : x(x), y(y), z(z) {}

Vec3i &Vec3i::operator+=(Vec3i const &rhs) {
  x += rhs.x;
  y += rhs.y;
  z += rhs.z;
  return *this;
}
Vec3i &Vec3i::operator-=(Vec3i const &rhs) {
  x -= rhs.x;
  y -= rhs.y;
  z -= rhs.z;
  return *this;
}

Vec3i &Vec3i::operator*=(int32_t rhs) {
  x *= rhs;
  y *= rhs;
  z *= rhs;
  return *this;
}

Vec3i &Vec3i::operator/=(int32_t rhs) {
  x /= rhs;
  y /= rhs;
  z /= rhs;
  return *this;
}

int32_t &Vec3i::operator[](size_t id) { return m_coord[id]; }

int32_t const &Vec3i::operator[](size_t id) const { return m_coord[id]; }

int32_t *Vec3i::data() { return &m_coord[0]; }

int32_t const *Vec3i::data() const { return &m_coord[0]; }

void Vec3i::zero() {
  x = 0;
  y = 0;
  z = 0;
}

// Free function
/*
 * Vector-Vector Addition/ Subtraction
 */
Vec3i operator+(Vec3i const &a, Vec3i const &b) {
  return Vec3i(a.x + b.x, a.y + b.y, a.z + b.z);
}
Vec3i operator-(Vec3i const &a, Vec3i const &b) {
  return Vec3i(a.x - b.x, a.y - b.y, a.z - b.z);
}

/*
 * Scalar-Vector Multiplication/Division
 */
Vec3i operator*(int32_t s, Vec3i v) {
  v.x *= s;
  v.y *= s;
  v.z *= s;
  return v;
}
Vec3i operator*(Vec3i v, int32_t s) { return s * v; }

Vec3i operator/(Vec3i v, int32_t s) {
  v.x /= s;
  v.y /= s;
  v.z /= s;
  return v;
}

/*
 * Negation of vector
 * -v = (-1.f) * v
 */
Vec3i operator-(Vec3i v) {
  v.x = -v.x;
  v.y = -v.y;
  v.z = -v.z;
  return v;
}

/*
 * Vector-Vector (inner/dot) product
 */
float operator*(Vec3i const &a, Vec3i const &b) {
  return a.x * b.x + a.y * b.y + a.z * b.z;
}
float dot(Vec3i const &a, Vec3i const &b) { return a * b; }

/*
 * Vector norm (length)
 */
float norm(Vec3i const &v) {
  return std::sqrt(v.x * v.x + v.y * v.y + v.z * v.z);
}
float normSquared(Vec3i const &v) { return v.x * v.x + v.y * v.y + v.z * v.z; }

/*
 * Linear int32_terpolation
 */
Vec3i lerp(Vec3i const &a, Vec3i const &b, float t) {
  return (1.f - t) * a + t * b;
}

float distance(Vec3i const &a, Vec3i const &b) { return norm(a - b); }

float distanceSquared(Vec3i const &a, Vec3i const &b) {
  return normSquared(a - b);
}

Vec3i componentMultiplication(const Vec3i &lhs, const Vec3i &rhs) {
  return {lhs.x * rhs.x, lhs.y * rhs.y, lhs.z * rhs.z};
}

std::ostream &operator<<(std::ostream &out, Vec3i const &v) {
  return out << v.x << " " << v.y << " " << v.z;
}

std::istream &operator>>(std::istream &in, Vec3i &v) {
  return in >> v.x >> v.y >> v.z;
}

} // namespace math
