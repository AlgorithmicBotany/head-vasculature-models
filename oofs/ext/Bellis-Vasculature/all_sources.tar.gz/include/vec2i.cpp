#include "vec2i.h"

#include <cmath>
#include <iostream>

namespace math {

Vec2i::Vec2i(int32_t x, int32_t y) : x(x), y(y) {}

Vec2i::Vec2i() : Vec2i(0, 0) {}

Vec2i &Vec2i::operator+=(Vec2i const &rhs) {
  x += rhs.x;
  y += rhs.y;
  return *this;
}
Vec2i &Vec2i::operator-=(Vec2i const &rhs) {
  x -= rhs.x;
  y -= rhs.y;
  return *this;
}

Vec2i &Vec2i::operator*=(int32_t rhs) {
  x *= rhs;
  y *= rhs;
  return *this;
}

Vec2i &Vec2i::operator/=(int32_t rhs) {
  x /= rhs;
  y /= rhs;
  return *this;
}

int32_t *Vec2i::data() { return &coord[0]; }

int32_t const *Vec2i::data() const { return &coord[0]; }

void Vec2i::zero() {
  x = 0;
  y = 0;
}

// Free function
/*
 * Vector-Vector Addition/ Subtraction
 */
Vec2i operator+(Vec2i const &a, Vec2i const &b) {
  return Vec2i(a.x + b.x, a.y + b.y);
}
Vec2i operator-(Vec2i const &a, Vec2i const &b) {
  return Vec2i(a.x - b.x, a.y - b.y);
}

/*
 * Scalar-Vector Multiplication/Division
 */
Vec2i operator*(int32_t s, Vec2i v) {
  v.x *= s;
  v.y *= s;
  return v;
}
Vec2i operator*(Vec2i v, int32_t s) { return s * v; }

Vec2i operator/(Vec2i v, int32_t s) {
  v.x /= s;
  v.y /= s;
  return v;
}

/*
 * Negation of vector
 * -v = (-1.f) * v
 */
Vec2i operator-(Vec2i v) {
  v.x = -v.x;
  v.y = -v.y;
  return v;
}

/*
 * Vector-Vector (inner/dot) product
 */
float operator*(Vec2i const &a, Vec2i const &b) {
  return a.x * b.x + a.y * b.y;
}
float dot(Vec2i const &a, Vec2i const &b) { return a * b; }

/*
 * Vector norm (length)
 */
float norm(Vec2i const &v) { return std::sqrt(v * v); }
float normSquared(Vec2i const &v) { return v * v; }

float distance(Vec2i const &a, Vec2i const &b) { return norm(a - b); }

float distanceSquared(Vec2i const &a, Vec2i const &b) {
  return normSquared(a - b);
}

Vec2i componentMultiplication(const Vec2i &lhs, const Vec2i &rhs) {
  return {lhs.x * rhs.x, lhs.y * rhs.y};
}

Vec2i componentMaximum(Vec2i const &a, Vec2i const &b) {
  using std::max;
  return {max(a.x, b.x), //
          max(a.y, b.y)};
}

Vec2i componentMinimum(Vec2i const &a, Vec2i const &b) {
  using std::min;
  return {min(a.x, b.x), //
          min(a.y, b.y)};
}

bool operator<=(Vec2i const &a, Vec2i const &b) {
  if (b.x < a.x)
    return false;
  if (b.y < a.y)
    return false;
  return true;
}

std::ostream &operator<<(std::ostream &out, Vec2i const &v) {
  return out << v.x << " " << v.y;
}

std::istream &operator>>(std::istream &in, Vec2i &v) {
  return in >> v.x >> v.y;
}

} // namespace math
