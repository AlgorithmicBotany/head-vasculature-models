#pragma once

#include <algorithm>
//#include <optional>
#include <vector>

namespace utility {

template <class T> std::vector<T> makeSortedUnique(std::vector<T> v) {
  std::sort(std::begin(v), std::end(v));
  auto iter = std::unique(std::begin(v), std::end(v));
  v.erase(iter, std::end(v));
  return v;
}

template <class Vector>
typename Vector::iterator swap_pop(Vector &v, size_t index) {
  using std::swap;
  swap(v.back(), v[index]);
  v.pop_back();
  return std::next(std::begin(v), index);
}

// template <class Vector, class Value = typename Vector::value_type>
// typename std::optional<Value> find(Value const &value, Vector const &v) {
//  auto iter = std::find(std::begin(v), std::end(v), value);
//  if (iter == std::end(v))
//    return std::nullopt;
//
//  return *iter;
//}

template <class Vector, class Value = typename Vector::value_type>
bool contains(Value const &value, Vector const &v) {
  auto iter = std::find(std::begin(v), std::end(v), value);
  if (iter == std::end(v))
    return false;

  return true;
}

template <class Vector> void append(Vector const &source, Vector &destination) {
  destination.reserve(source.size() + destination.size());
  destination.insert(std::end(destination), // place
                     std::begin(source),    // data to copy
                     std::end(source));
}

template <class Vector, class Value = typename Vector::value_type>
void remove(Value const &value, Vector &vec) {
  using namespace std;
  vec.erase(remove(begin(vec), end(vec), value), end(vec));
}

template <class Vector, class Value = typename Vector::value_type>
bool attemptRemoveUnique(Value const &value, Vector &vec) {
  using namespace std;
  auto iter = remove(begin(vec), end(vec), value);
  if (iter == end(vec))
    return false;
  vec.erase(iter, end(vec));
  return true;
}

template <class T, class Match>
bool isUniqueAmoung(T const &value, std::vector<T> const &values,
                    Match matchFunc) {
  for (auto const &v : values) {
    if (matchFunc(value, v))
      return false;
  }
  return true;
}

} // namespace utility
