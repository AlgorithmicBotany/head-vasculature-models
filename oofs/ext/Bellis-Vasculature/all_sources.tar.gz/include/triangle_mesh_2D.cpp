#include "triangle_mesh_2D.h"

namespace geometry {

TriangleMesh2D::TriangleMesh2D(vertices_t vertices, triangles_t indexTriangles)
    : m_vertices(vertices), m_indexTriangles(indexTriangles) {}

TriangleMesh2D::vertices_t const &TriangleMesh2D::vertices() const {
  return m_vertices;
}

TriangleMesh2D::vertices_t &TriangleMesh2D::vertices() { return m_vertices; }

TriangleMesh2D::triangles_t const &TriangleMesh2D::triangles() const {
  return m_indexTriangles;
}

TriangleMesh2D::triangles_t &TriangleMesh2D::triangles() {
  return m_indexTriangles;
}

size_t TriangleMesh2D::vertexCount() const { return m_vertices.size(); }

size_t TriangleMesh2D::triangleCount() const { return m_indexTriangles.size(); }

TriangleMesh2D::triangle_t const *TriangleMesh2D::triangleData() const {
  return m_indexTriangles.data();
}

TriangleMesh2D::vertex_t const *TriangleMesh2D::vertexData() const {
  return m_vertices.data();
}

TriangleMesh2D::VertexID const *TriangleMesh2D::indiciesPointer() const {
  return (VertexID *)(triangleData());
}

size_t TriangleMesh2D::indicesCount() const { return triangleCount() * 3; }

bool TriangleMesh2D::empty() const { return m_vertices.empty(); }

} // namespace geometry
