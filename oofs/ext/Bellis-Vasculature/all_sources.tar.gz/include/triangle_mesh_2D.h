#pragma once

#include <cstdint>

#include "edge.h"
#include "triangle.h"
#include "vec2f.h"

namespace geometry {

class TriangleMesh2D {
public:
  using VertexID = uint32_t;
  using vertex_t = math::Vec2f;
  using triangle_t = geometry::Triangle<VertexID>;

  using triangles_t = std::vector<triangle_t>;
  using vertices_t = std::vector<vertex_t>;

public:
  TriangleMesh2D() = default;
  TriangleMesh2D(vertices_t vertices, triangles_t indexTriangles);

  vertices_t const &vertices() const;

  vertices_t &vertices();

  triangles_t const &triangles() const;

  triangles_t &triangles();

  size_t vertexCount() const;

  size_t triangleCount() const;

  triangle_t const *triangleData() const;

  vertex_t const *vertexData() const;

  VertexID const *indiciesPointer() const;

  size_t indicesCount() const;

  bool empty() const;

private:
  vertices_t m_vertices;
  triangles_t m_indexTriangles;
};

} // namespace geometry
