#pragma once

#include "cage_deformation_2D.h"
#include "curve.h"
#include "timestamp_primordia_file_io.h"
#include "vec3f.h"

namespace modelling {
namespace phyllotaxis {

struct GrowingReceptacle {
  MeshCageDeformation cageDeformations;
  uint32_t currentCageID{0};

  void reload(modelling::MeshCageDeformation deformations);

  MeshCage const &currentCage() const;
  float currentTime() const;
  bool isFullGrown() const;

  void step();

  size_t size() const;
};

struct ReceptaclePoint {
  math::Vec3f p, n;
};

ReceptaclePoint receptaclePoint(float arcDistance, float azimuthRadians,
                                MeshCage const &receptacle);
ReceptaclePoint receptaclePoint(TimestampPrimordia const &prim,
                                MeshCage const &receptacle);
ReceptaclePoint receptaclePoint(TimestampPrimordia const &prim,
                                GrowingReceptacle const &growingReceptacle);

//
// Random sampling utility
//

math::Vec3f randomPointNearSurfaceAt(float arcDistance, float depthMin,
                                     float depthMax,
                                     MeshCage const &receptacle);

// TODO add elsewhere
std::vector<math::Vec3f>
generateNewAdaxialAuxin(int count, float threshold,
                        std::vector<math::Vec3f> const &points,
                        float arcDistance, MeshCage const &receptacle);

} // namespace phyllotaxis
} // namespace modelling
