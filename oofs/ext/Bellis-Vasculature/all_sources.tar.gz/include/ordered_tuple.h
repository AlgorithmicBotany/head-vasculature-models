/**
 * @file	ordered_tuple.h
 * @author	Andrew Robert Owens
 * Contact:	arowens [at] ucalgary.ca
 * @date	2018-2-23.
 *
 * @brief	CollisionExample
 * @details Organization: Biological Modeling and Visualization research group
 * University of Calgary, Calgary, AB, Canada
 *
 * @copyright Copyright (c) 2018 ___ALGORITHMIC_BOTANY___. All rights reserved.
 *
 * @brief
 */

#pragma once

#include <array>
#include <iostream>

#include "math_utility.h"

namespace math {

template <typename T, size_t N> using Tuple = std::array<T, N>;

template <typename T> Tuple<T, 2> const makeOrdered_tuple(T a, T b) {
  using std::swap;
  if (b < a)
    swap(b, a);
  return {a, b};
}
template <class T> struct Ordered2Tuple : public Tuple<T, 2> {
  using store_t = Tuple<T, 2>;

  Ordered2Tuple(T a, T b) : store_t(makeOrdered_tuple(a, b)) {}

  operator store_t() const { return *this; }

  T a() const { return store_t::operator[](0); }
  T b() const { return store_t::operator[](1); }
};

template <typename T> Tuple<T, 3> const makeOrdered_tuple(T a, T b, T c) {
  using std::swap;
  // sort a
  if (b < a)
    swap(b, a);
  if (c < a)
    swap(c, a);

  // sort b
  if (c < b)
    swap(c, b);

  return {a, b, c};
}

template <typename T> Tuple<T, 4> const makeOrdered_tuple(T a, T b, T c, T d) {
  using std::swap;
  // sort a
  if (b < a)
    swap(b, a);
  if (c < a)
    swap(c, a);
  if (d < a)
    swap(d, a);

  // sort b
  if (c < b)
    swap(c, b);
  if (d < b)
    swap(d, b);

  // sort c
  if (d < c)
    swap(d, c);

  return {a, b, c, d};
}

} // namespace math
