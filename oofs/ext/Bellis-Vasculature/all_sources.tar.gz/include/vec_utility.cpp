#include "vec_utility.h"

#include "math_utility.h"

namespace math {

math::Vec2i clamp(math::Vec2i const &a, math::Vec2i const &lo,
                  math::Vec2i const hi) {
  return {math::clamp(a.x, lo.x, hi.x), //
          math::clamp(a.y, lo.y, hi.y)};
}

math::Vec3f clamp(math::Vec3f const &a, math::Vec3f const &lo,
                  math::Vec3f const hi) {
  return {math::clamp(a.x, lo.x, hi.x), //
          math::clamp(a.y, lo.y, hi.y), math::clamp(a.z, lo.z, hi.z)};
}

math::Mat3f arbitraryOrientationFrom(math::Vec3f y) {
  y.normalize();
  auto x = arbitraryOrthogonalTo(y);
  x.normalize();
  auto z = x ^ y;
  z.normalize(); // optional

  return mat3f::fromColumns(x, y, z);
}

Vec4f toHomogeneousCoordinate(Vec3f const &ndc, float w) {
  // w = 0 : vector
  // w = 1 : point
  return {ndc.x, ndc.y, ndc.z, w};
}

Vec4f perspectiveDivide(Vec4f homogeneousCoordinate) {
  homogeneousCoordinate /= homogeneousCoordinate.w;
  return homogeneousCoordinate;
}

} // namespace math
