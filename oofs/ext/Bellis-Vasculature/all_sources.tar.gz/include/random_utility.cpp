#include "random_utility.h"

#include <random>

namespace randutil {

std::mt19937 &gen() {
  static std::mt19937 s_gen{0}; // Standard mersenne_twister_engine seeded
  return s_gen;
}

void seed(unsigned int s) { gen() = std::mt19937{s}; }

float uniformFloat() {
  using distrubution = std::uniform_real_distribution<>;
  return distrubution(0.f, 1.f)(gen());
}

float uniform(float a, float b) {
  using distrubution = std::uniform_real_distribution<>;
  return distrubution(a, b)(gen());
}

template <> int uniform<int>(int a, int b) {
  using distrubution = std::uniform_int_distribution<>;
  return distrubution(a, b)(gen());
}

math::Vec3f uniformVec3f() {
  return {uniformFloat(), uniformFloat(), uniformFloat()};
}

math::Vec3f uniform(math::Vec3f const &lo, math::Vec3f const &hi) {
  return {uniform(lo.x, hi.x), uniform(lo.y, hi.y), uniform(lo.z, hi.z)};
}

float gaussian(float sigma) {
  using distribution = std::normal_distribution<float>;
  return distribution{0.f, sigma}(gen());
}

float gaussian(float sigma, float mu) {
  using distribution = std::normal_distribution<float>;
  return distribution{mu, sigma}(gen());
}

math::Vec3f gaussianVec3f(float sigma) {
  return {gaussian(sigma), gaussian(sigma), gaussian(sigma)};
}

math::Vec3f gaussianVec3f(float sigma, float mu) {
  return {gaussian(sigma, mu), gaussian(sigma, mu), gaussian(sigma, mu)};
}

math::Vec2f gaussianVec2f(float sigma) {
  return {gaussian(sigma), gaussian(sigma)};
}

math::Vec2f gaussianVec2f(float sigma, float mu) {
  return {gaussian(sigma, mu), gaussian(sigma, mu)};
}

math::Vec3f uniformSphere() {
  float theta = 2.f * M_PI * uniform(0.f, 1.f);
  float phi = acos(1.f - 2.f * uniform(0.f, 1.f));
  float x = sin(phi) * cos(theta);
  float y = sin(phi) * sin(theta);
  float z = cos(phi);
  return {x, y, z};
}

// https://pbr-book.org/3ed-2018/Monte_Carlo_Integration/2D_Sampling_with_Multidimensional_Transformations#fragment-SamplingFunctionDefinitions-6
math::Vec3f uniformHemisphere() {
  float z = uniformFloat();
  float r = std::sqrt(std::max(0.f, 1.f - z * z));
  float phi = 2.f * M_PI * uniformFloat();
  return {r * std::cos(phi), r * std::sin(phi), z};
}

// https://pbr-book.org/3ed-2018/Monte_Carlo_Integration/2D_Sampling_with_Multidimensional_Transformations#fragment-SamplingFunctionDefinitions-6
math::Vec3f uniformHemisphere(math::Vec3f const &normal,
                              math::Vec3f const &tangent) {
  float z = uniformFloat();
  float r = std::sqrt(std::max(0.f, 1.f - z * z));
  float phi = uniform(0.f, 360.f);
  return normal * z +
         math::rotateAroundNormalizedAxis(r * tangent, normal, phi);
}

math::Vec3f uniformCircle() {
  float theta = uniform(0.f, 360.f);
  return math::rotateAroundAxis(math::axis3::X, math::axis3::Y, theta);
}

math::Vec3f uniformCircleAroundAxis(math::Vec3f const &axis) {
  float theta = uniform(0.f, 360.f);
  auto x = math::arbitraryOrthogonalTo(axis);
  return math::rotateAroundAxis(x, axis, theta);
}

math::Vec3f uniformCylinder(float height, float r) {
  float h = uniform(0.f, height);
  float phi = uniform(0.f, 2.f * M_PI);

  float x = r * sin(phi);
  float z = r * cos(phi);
  return {x, h, z};
}

math::Vec3f jitterDirection(math::Vec3f v, float probabilityOfJitter,
                            float strengthMin, float strengthMax) {
  auto delta = uniformSphere();
  delta = math::orthogonalize(delta, math::normalized(v)) *
          uniform(strengthMin, strengthMax);

  return (uniformFloat() <= probabilityOfJitter) ? v + delta : v;
}

} // namespace randutil
