#pragma once

// std for c++17+
//#include <optional>
// non std for c++11
#include "optional.hpp"

#include <utility>
#include <vector>

#include "barycentric_coordinates.h"
#include "cage_weight_utility.h"
#include "curve.h"
#include "triangle_mesh_2D.h"

namespace modelling {

struct MeshCage {
  using WeightField = std::vector<float>;
  using Mesh = geometry::TriangleMesh2D;
  using Face = geometry::TriangleMesh2D::triangle_t;

  geometry::Curve2f controlPoints;
  std::vector<WeightField> controlPointFields;

  Mesh mesh;
};

struct CurvePointNormal {
  math::Vec2f p;
  math::Vec2f n;
};

CurvePointNormal curvePointNormal(float fraction,
                                  geometry::Curve2f const &controlPoints,
                                  size_t ignoredTailCPs = 20);

using MeshCageDeformation = std::vector<MeshCage>;

std::vector<PositionWeights>
calculateCageWeightOf(std::vector<math::Vec2f> const &positions,
                      MeshCage const &cage);

void insitu_cageDeformPoints(std::vector<math::Vec2f> &points,
                             MeshCage const &currentMesh,
                             MeshCage const &nextMesh);

void insitu_deformVolumeOfRevolutionPoints(
    std::vector<math::Vec3f> &pointInVolume, MeshCage const &currentCage,
    MeshCage const &nextCage);

struct CoordinatesWithinFace {
  MeshCage::Face face;
  math::BarycentricCoordinates bary;
};

//std::optional<CoordinatesWithinFace>
nonstd::optional<CoordinatesWithinFace>
findFaceContaining(math::Vec2f const &p, geometry::TriangleMesh2D const &mesh);

//std::optional<CoordinatesWithinFace>
nonstd::optional<CoordinatesWithinFace>
findClosestEdge(math::Vec2f const &p, geometry::TriangleMesh2D const &mesh);

} // namespace modelling
