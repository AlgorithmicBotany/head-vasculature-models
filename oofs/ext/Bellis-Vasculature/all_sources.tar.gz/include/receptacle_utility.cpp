#include "receptacle_utility.h"

#include "math_utility.h"
#include "random_utility.h"

#include "containers_utility.h"
#include "poisson_point_set.h"

namespace modelling {
namespace phyllotaxis {

void GrowingReceptacle::reload(modelling::MeshCageDeformation deformations) {
  cageDeformations = std::move(deformations);
  currentCageID = 0;
}

MeshCage const &GrowingReceptacle::currentCage() const {
  return cageDeformations[currentCageID];
}

float GrowingReceptacle::currentTime() const {
  return float(currentCageID) / float(cageDeformations.size() - 1);
}

void GrowingReceptacle::step() {
  if (isFullGrown())
    return;

  ++currentCageID;
}

bool GrowingReceptacle::isFullGrown() const {
  return currentCageID + 1 >= cageDeformations.size();
}

size_t GrowingReceptacle::size() const { return cageDeformations.size(); }

// TODO REMOVE CONTANT 20 (base control points)
ReceptaclePoint receptaclePoint(float arcDistance, float azimuth_rad,
                                MeshCage const &receptacle) {
  auto point = curvePointNormal(arcDistance, receptacle.controlPoints, 20);
  auto p = math::vec3f::from(point.p);
  auto n = math::vec3f::from(point.n);

  // negated angles to match the CW rotations of Phyllotaxis paper
  // (see phyllotaxis model)
  p = math::rotateAroundY_rad(p, azimuth_rad);
  n = math::rotateAroundY_rad(n, azimuth_rad);

  return {p, n};
}

ReceptaclePoint receptaclePoint(TimestampPrimordia const &prim,
                                MeshCage const &receptacle) {

  // negated angles to match the CW rotations of Phyllotaxis paper
  // (see phyllotaxis model)
  return receptaclePoint(prim.fraction, -prim.angle, receptacle);
}

ReceptaclePoint receptaclePoint(TimestampPrimordia const &prim,
                                GrowingReceptacle const &growingReceptacle) {
  return receptaclePoint(prim, growingReceptacle.currentCage());
}

math::Vec3f randomPointNearSurfaceAt(float arcDistance, float depthMin,
                                     float depthMax,
                                     MeshCage const &receptacle) {
  auto rot = randutil::uniform(0.f, 2.f * M_PI);

  auto rPoint = receptaclePoint(arcDistance, rot, receptacle);
  rPoint.p += rPoint.n * randutil::uniform(depthMin, depthMax);
  return rPoint.p;
}

// TODO Move elsewhere?
std::vector<math::Vec3f>
generateNewAdaxialAuxin(int requestCount, float threshold,
                        std::vector<math::Vec3f> const &points,
                        float arcDistance, MeshCage const &receptacle) {

  auto thresholdSqrd = threshold * threshold;
  auto matchFunc = [thresholdSqrd](math::Vec3f const &a, math::Vec3f const &b) {
    return distanceSquared(a, b) < thresholdSqrd;
  };
  auto generator = [arcDistance, &receptacle]() {
    return randomPointNearSurfaceAt(arcDistance, 0.65f, 0.66f, receptacle);
  };

  return randutil::generatePoissonDiskPointsAmoungst(points, requestCount, //
                                                     generator,            //
                                                     matchFunc);
}

} // namespace phyllotaxis
} // namespace modelling
