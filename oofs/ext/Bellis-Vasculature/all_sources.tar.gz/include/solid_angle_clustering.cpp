#include "solid_angle_clustering.h"

#include <algorithm>
#include <iostream>
#include <iterator>

#include "math_utility.h"

namespace clustering {

bool areOverlapping(SpherePoint const &a, SpherePoint const &b,
                    float baseSolidAngle, float maxSolidAngle,
                    float normalizedFactor) {
  using namespace math;
  auto angleA = baseSolidAngle * (a.w / normalizedFactor);
  auto angleB = baseSolidAngle * (b.w / normalizedFactor);

  angleA = clamp(angleA, maxSolidAngle);
  angleB = clamp(angleB, maxSolidAngle);

  float angleAB = std::acos(clamp(dot(a.p, b.p), -1.f, 1.f));
  return angleAB < 0.5f * (angleA + angleB);
}

bool canFit(SpherePoint const &p, std::vector<SpherePoint> const &points,
            float baseSolidAngle, float maxSolidAngle, float normalizedFactor) {
  for (auto const &point : points) {
    if (areOverlapping(p, point, baseSolidAngle, maxSolidAngle,
                       normalizedFactor)) {
      return false;
    }
  }
  return true;
}

SolidAngleCluster
selectSolidAngleClusterAround(math::Vec3f const &center,
                              std::vector<math::Vec3f> const &points,
                              float baseSolidAngle, float maxSolidAngle) {
  SolidAngleCluster selectedPoints;

  SolidAngleCluster projectedPoints;
  projectedPoints.reserve(points.size());
  for (auto const &point : points) {
    auto dir = point - center;
    auto dist = norm(dir);

    if (dist < 1e-5f) {
      //std::cerr << "solid angle: comparing the same\n";
      continue;
    }

    dir /= dist; // weight
    projectedPoints.push_back(SpherePoint{dir, dist});
  }

  std::sort(std::begin(projectedPoints), std::end(projectedPoints),
            [](auto const &a, auto const &b) { return a.w < b.w; });
  // opitionally, sort while inserting?

  for (auto const &p : projectedPoints) {
    if (canFit(p, selectedPoints, baseSolidAngle, maxSolidAngle,
               projectedPoints[0].w))
      selectedPoints.push_back(p);
  }

  return selectedPoints;
}

} // namespace clustering
