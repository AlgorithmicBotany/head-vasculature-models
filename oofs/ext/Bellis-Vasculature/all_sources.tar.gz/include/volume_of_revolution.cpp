#include "volume_of_revolution.h"

#include <algorithm>

namespace modelling {

// Volumetric (3D) simulations
math::Vec2f rotateIntoXY_Quadrants_1_4(math::Vec3f const &p) {
  using namespace math;
  return Vec2f(norm(Vec2f(p.x, p.z)), p.y);
}

std::vector<math::Vec2f>
projectToVolumeOfRevolutionDomain(std::vector<math::Vec3f> const &positions) {
  using namespace std;
  vector<math::Vec2f> tmp(positions.size());
  transform(begin(positions), //
            end(positions),   //
            begin(tmp), rotateIntoXY_Quadrants_1_4);
  return tmp;
}

math::Vec3f
inverse_projectTo2DRevolutionFrom3D(math::Vec2f const &volumeCoordinates,
                                    math::Vec3f originalCoordinates) {
  using namespace math;
  Vec3f rAxis(originalCoordinates.x, 0.f, originalCoordinates.z);
  float length = norm(rAxis);
  if (!isZero(length)) {
    rAxis /= length;
  }

  return rAxis * volumeCoordinates.x + math::axis3::Y * volumeCoordinates.y;
}

void insitu_inverse_projectToVolumeOfRevolution(
    std::vector<math::Vec3f> &originalCoordinates,
    std::vector<math::Vec2f> const &volumeCoordinates) {
  for (uint32_t index = 0; index < volumeCoordinates.size(); ++index) {
    auto &op = originalCoordinates[index];
    op = inverse_projectTo2DRevolutionFrom3D(volumeCoordinates[index], op);
  }
}

// Flat (2D) simulations
math::Vec2f reflectIntoXY_Quadrant_1_4(math::Vec2f const &p) {
  return math::Vec2f(std::abs(p.x), p.y);
}

math::Vec2f
inverse_projectToMirroredRegion(math::Vec2f const &volumeCoordinates,
                                math::Vec2f originalCoordinates) {
  using namespace math;
  originalCoordinates.x = sgn(originalCoordinates.x) * volumeCoordinates.x;
  originalCoordinates.y = volumeCoordinates.y;
  return originalCoordinates;
}

std::vector<math::Vec2f>
projectToMirroredRegion(std::vector<math::Vec2f> const &positions) {
  using namespace std;
  vector<math::Vec2f> tmp(positions.size());
  transform(begin(positions), //
            end(positions),   //
            begin(tmp), reflectIntoXY_Quadrant_1_4);
  return tmp;
}

void insitu_inverse_projectToMirroredRegion(
    std::vector<math::Vec2f> const &volumeCoordinates,
    std::vector<math::Vec2f> &originalCoordinates) {
  for (uint32_t id = 0; id < volumeCoordinates.size(); ++id) {
    originalCoordinates[id] = inverse_projectToMirroredRegion(
        volumeCoordinates[id], originalCoordinates[id]);
  }
}

} // namespace modelling
