#include "math_utility.h"

namespace math {

float fractional(float x, int sgn) {
  if (sgn > 0)
    return 1.f - x + std::floor(x);
  else
    return x - std::floor(x);
}

float wrapToMax(float x, float m) {
  x = std::fmod(x, m);
  if (x < 0.f) {
    x += m;
  }
  return x;
}

float wrapToRange(float x, float a, float b) {
  return a + wrapToMax(x - a, b - a);
}

float gaussian(float x, float sigma) {
  float invSigma = 1.f / sigma;
  float const invSqrt2PI = 1.f / std::sqrt(2.f * M_PI);
  float a = x * invSigma;
  return (invSqrt2PI * invSigma) * std::exp(-0.5f * a * a);
}

float gaussian_Derivative1(float phi, float sigma) {
  auto sigma2 = sigma * sigma;
  return (-phi / sigma2) * gaussian(phi, sigma);
}

float gaussian_Derivative2(float phi, float sigma) {
  auto phi2 = phi * phi;
  auto sigma2 = sigma * sigma;
  return (phi2 - sigma2) / (sigma2 * sigma2) * gaussian(phi, sigma);
}

float gaussian(float x, float mu, float sigma) {
  return gaussian(x - mu, sigma);
}

float gaussian_Derivative1(float x, float mu, float sigma) {
  return gaussian_Derivative1(x - mu, sigma);
}

float gaussian_Derivative2(float x, float mu, float sigma) {
  return gaussian_Derivative2(x - mu, sigma);
}

float wyvillFallOff(float x, float R) {
  using std::pow;
  if (std::abs(x) > R)
    return 0.f;

  auto x_R = x / R;
  return 1.f - 3.f * pow(x_R, 2.f) + 3.f * pow(x_R, 4.f) - pow(x_R, 6.f);
}

float wyvillFallOff_Derivative1(float x, float R) {
  using std::pow;
  if (std::abs(x) > R)
    return 0.f;

  auto x_R = x / R;
  return -6.f * x_R + 12.f * pow(x_R, 3.f) - 6.f * pow(x_R, 5.f);
}

float wyvillFallOff_Derivative2(float x, float R) {
  using std::pow;
  if (std::abs(x) > R)
    return 0.f;

  auto x_R = x / R;
  return -6.f + 36.f * pow(x_R, 2.f) - 30.f * pow(x_R, 4.f);
}

float normalizedBump(float x, float R, int n) {
  if (std::abs(x) > R)
    return 0.f;

  return M_E * std::exp(-1.f / (1.f - std::pow(x / R, 2.f * n)));
}

float smoothstep(float x, float edge0, float edge1) {
  if (x <= edge0)
    return 0.f;
  if (x >= edge1)
    return 1.f;

  x = math::mapToUnitInterval(x, edge0, edge1);
  return x * x * (3.f - 2.f * x);
}

} // namespace math
