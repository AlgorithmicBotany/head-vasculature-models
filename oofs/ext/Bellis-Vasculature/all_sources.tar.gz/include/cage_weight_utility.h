#pragma once

#include <vector>
#include <cstdint>

namespace modelling {

using PositionWeights = std::vector<float>;

template <typename T>
std::vector<T> calculatePositionsFromWeights(
    std::vector<PositionWeights> const &positionWeights,
    std::vector<T> const &controlPoints) {
  std::vector<T> positions(positionWeights.size());

  for (uint32_t index = 0; index < positionWeights.size(); ++index) {
    auto const &w = positionWeights[index];
    auto &p = positions[index];

    p.zero();
    for (uint32_t cpIndex = 0; cpIndex < controlPoints.size(); ++cpIndex) {
      p += controlPoints[cpIndex] * w[cpIndex];
    }
  }

  return positions;
}

template <typename T>
std::vector<T>
calculateResiduals(std::vector<T> const &positions,
                   std::vector<PositionWeights> const &positionWeights,
                   std::vector<T> const &controlPoints) {
  auto residuals =
      calculatePositionsFromWeights<T>(positionWeights, controlPoints);

  for (uint32_t id = 0; id < residuals.size(); ++id) {
    residuals[id] = positions[id] - residuals[id];
  }

  return residuals;
}

template <typename T>
void removeResiduals(std::vector<T> &positions, std::vector<T> const &residuals,
                     T padding) {

  for (uint32_t id = 0; id < positions.size(); ++id) {
    positions[id] += residuals[id] + padding;
  }
}

} // namespace modelling
