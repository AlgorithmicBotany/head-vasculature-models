#include "cage_deformation_2D.h"

#include <fstream>
#include <iostream>

#include "geometry_utility.h"
#include "math_utility.h"
#include "volume_of_revolution.h"

namespace modelling {

CurvePointNormal curvePointNormal(float fraction,
                                  geometry::Curve2f const &controlPoints,
                                  size_t ignoredTailCPs) {
  using namespace math;
  CurvePointNormal out;

  int lastID = (controlPoints.size() - ignoredTailCPs);
  auto cp_L = geometry::partitionLength(controlPoints, 0, lastID);

  fraction *= cp_L;

  float accum = 0.f;
  for (int id = 0; id < lastID; ++id) {
    auto const &a = controlPoints[id];
    auto const &b = controlPoints[id + 1];
    auto dAB = distance(a, b);

    accum += dAB;
    if (accum >= fraction) {
      float diff = accum - fraction;
      float t = diff / dAB;
      auto p = lerp(b, a, t);

      auto n = perpendicularTo(a - b);
      out.p = p;
      out.n = math::normalized(n);
      break;
    }
  }

  return out;
}

// std::optional<CoordinatesWithinFace>
nonstd::optional<CoordinatesWithinFace>
findFaceContaining(math::Vec2f const &p, geometry::TriangleMesh2D const &mesh) {
  CoordinatesWithinFace foundFace;

  auto const &verts = mesh.vertices();
  for (auto const &face : mesh.triangles()) {
    auto a = verts[face.a];
    auto b = verts[face.b];
    auto c = verts[face.c];

    auto bary = barycentricCoordinates(a, b, c, p);
    if (math::isConvex(bary)) {
      foundFace.face = face;
      foundFace.bary = bary;
      return foundFace;
    }
  }

  return nonstd::nullopt;
}

// std::optional<CoordinatesWithinFace>
nonstd::optional<CoordinatesWithinFace>
findClosestEdge(math::Vec2f const &p, geometry::TriangleMesh2D const &mesh) {
  CoordinatesWithinFace foundFace;

  if (mesh.empty())
    return nonstd::nullopt;

  float minDist = std::numeric_limits<float>::max();

  auto const &verts = mesh.vertices();
  for (auto const &face : mesh.triangles()) {
    auto a = verts[face.a];
    auto b = verts[face.b];
    auto c = verts[face.c];

    {
      auto cbPoint = geometry::closestToLineSegment(b, c, p);
      auto cbDist = math::distance(cbPoint, p);
      if (cbDist < minDist) {
        foundFace.bary = barycentricCoordinates(a, b, c, cbPoint);
        foundFace.face = face;
        minDist = cbDist;
      }
    }
    {
      auto baPoint = geometry::closestToLineSegment(a, b, p);
      auto baDist = math::distance(baPoint, p);
      if (baDist < minDist) {
        foundFace.bary = barycentricCoordinates(a, b, c, baPoint);
        foundFace.face = face;
        minDist = baDist;
      }
    }
    {
      auto caPoint = geometry::closestToLineSegment(a, c, p);
      auto caDist = math::distance(caPoint, p);
      if (caDist < minDist) {
        foundFace.bary = barycentricCoordinates(a, b, c, caPoint);
        foundFace.face = face;
        minDist = caDist;
      }
    }
  }

  return foundFace;
}

std::vector<CoordinatesWithinFace>
findAndProjectIntoNearestFaces(std::vector<math::Vec2f> &positions,
                               geometry::TriangleMesh2D const &mesh) {

  static std::vector<CoordinatesWithinFace> containingFace;

  auto const &verts = mesh.vertices();
  containingFace.resize(positions.size());

  int positionID = 0;
  for (auto &p : positions) {

    auto didFindFace = findFaceContaining(p, mesh);

    CoordinatesWithinFace foundFace;

    if (didFindFace) {
      foundFace = *didFindFace;
    } else {
      auto project = findClosestEdge(p, mesh);

      auto foundFace = *project;
      auto const &a = verts[foundFace.face.a];
      auto const &b = verts[foundFace.face.b];
      auto const &c = verts[foundFace.face.c];
      p = math::blend(a, b, c, (*project).bary);
    }

    containingFace[positionID++] = foundFace;
  }

  return containingFace;
}

std::vector<PositionWeights>
calculateCageWeightOf(std::vector<math::Vec2f> &positions,
                      MeshCage const &cage) {
  using namespace std;
  using namespace geometry;

  auto const &cps = cage.controlPoints;
  auto const &fields = cage.controlPointFields;

  // preallocate control point weights for each position
  vector<PositionWeights> weights(
      positions.size(),           // one per position
      PositionWeights(cps.size()) // control point weights
  );

  // preallocate memory between calls, reused between calls
  static std::vector<CoordinatesWithinFace> foundFaces;
  foundFaces = findAndProjectIntoNearestFaces(positions, cage.mesh);

  for (uint32_t pID = 0; pID < positions.size(); ++pID) {
    auto const &foundFace = foundFaces[pID];
    auto &w = weights[pID];

    // store weights of p = sum w_i cp_i
    for (uint32_t cpIndex = 0; cpIndex < cps.size(); ++cpIndex) {
      auto const &cpField = fields[cpIndex];

      float wA = cpField[foundFace.face.a];
      float wB = cpField[foundFace.face.b];
      float wC = cpField[foundFace.face.c];

      // face vertex A was origin of uv calculations so it gets bary.w
      w[cpIndex] = math::blend(wA, wB, wC, foundFace.bary);
    }
  }

  return weights;
}

void insitu_cageDeformPoints(std::vector<math::Vec2f> &points,
                             MeshCage const &currentMesh,
                             MeshCage const &nextMesh) {
  static std::vector<PositionWeights> weights;
  weights = modelling::calculateCageWeightOf(points, currentMesh);

  // precalculate residuals from new basis approximation
  using modelling::calculateResiduals;
  auto residuals =
      calculateResiduals(points, weights, currentMesh.controlPoints.points());

  // new volume coordinates
  using modelling::calculatePositionsFromWeights;
  points =
      calculatePositionsFromWeights(weights, nextMesh.controlPoints.points());

  // remove residuals
  // https://graphics.pixar.com/library/HarmonicCoordinates/paper.pdf
  using modelling::removeResiduals;
  math::Vec2f padding(0.000001f, 0.000001f);
  removeResiduals(points, residuals, padding);
}

void insitu_deformVolumeOfRevolutionPoints(std::vector<math::Vec3f> &p_volume,
                                           MeshCage const &current,
                                           MeshCage const &next) {
  using namespace modelling;
  // 3D -> 2D
  auto p_contourRegion = projectToVolumeOfRevolutionDomain(p_volume);

  // Deform in 2D between stages (constant jump)
  // TODO cubic interpolation?
  insitu_cageDeformPoints(p_contourRegion, current, next);

  // 2D -> 3D positions (need original points for radial longitudinal axis)
  insitu_inverse_projectToVolumeOfRevolution(p_volume, p_contourRegion);
}

} // namespace modelling
