#pragma once

#include <array>
#include <iosfwd>

#include "vec2f.h"

namespace math {

// struct declaration
struct Vec3f {
  union {
    struct {
      float x;
      float y;
      float z;
    };
    //    float coord[3] = {0.f, 0.f, 0.f}; // TODO: clang seems to force
    //    this?
    float coord[3];
  };

  // Vec3f() = default; // TODO: clang issue from above
  Vec3f();
  explicit Vec3f(float all);
  Vec3f(float x, float y, float z);

  /*
   * Mutating member functions
   */
  Vec3f &operator+=(Vec3f const &rhs);
  Vec3f &operator-=(Vec3f const &rhs);
  Vec3f &operator*=(float rhs);
  Vec3f &operator/=(float rhs);

  Vec3f &operator=(Vec3f const &rhs) = default;

  float &operator[](size_t id);
  float const &operator[](size_t id) const;

  float *data();
  float const *data() const;

  Vec3f &normalize();
};

// TODO constexpr
namespace vec3f {
static const math::Vec3f zero{0.f, 0.f, 0.f};

math::Vec3f from(math::Vec2f const &v);
} // namespace vec3f

namespace vec2f {
math::Vec2f from(math::Vec3f const &v);
}

namespace axis3 {
static const math::Vec3f X{1.f, 0.f, 0.f};
static const math::Vec3f Y{0.f, 1.f, 0.f};
static const math::Vec3f Z{0.f, 0.f, 1.f};
}; // namespace axis3

// Free function declarations
Vec3f operator+(Vec3f const &a, Vec3f const &b);
Vec3f operator-(Vec3f const &a, Vec3f const &b);
Vec3f operator*(float s, Vec3f v);
Vec3f operator*(Vec3f v, float s);
Vec3f operator/(Vec3f v, float s);
Vec3f operator-(Vec3f v);

bool operator<(Vec3f const &a, Vec3f const &b);

float operator*(Vec3f const &a, Vec3f const &b);
float dot(Vec3f const &a, Vec3f const &b);

Vec3f operator^(Vec3f const &a, Vec3f const &b);
Vec3f cross(Vec3f const &a, Vec3f const &b);

float length(Vec3f const &v); // same as norm
float norm(Vec3f const &v);
float normSquared(Vec3f const &v);
float lengthSquared(Vec3f const &v); // same as norm
Vec3f normalized(Vec3f v);

// Linear interpolation from a to b by t
Vec3f lerp(Vec3f const &a, Vec3f const &b, float t);
Vec3f mid(Vec3f const &a, Vec3f const &b);
float distance(Vec3f const &a, Vec3f const &b);
float distanceSquared(Vec3f const &a, Vec3f const &b);

// rotations
Vec3f reflect(Vec3f const &v, Vec3f const &normal);
// degrees
Vec3f rotateAroundAxis(Vec3f const &v, Vec3f axis, float angleDegrees);
Vec3f rotateAroundNormalizedAxis(Vec3f const &v, Vec3f const &axis,
                                 float angleDegrees);
Vec3f rotateAroundX(Vec3f const &v, float angleDegrees);
Vec3f rotateAroundY(Vec3f const &v, float angleDegrees);
Vec3f rotateAroundZ(Vec3f const &v, float angleDegrees);

// radians
Vec3f rotateAroundAxis_rad(Vec3f const &v, Vec3f axis, float angleRadians);
Vec3f rotateAroundNormalizedAxis_rad(Vec3f const &v, Vec3f const &axis,
                                     float angleRadians);
Vec3f rotateAroundX_rad(Vec3f const &v, float angleRadians);
Vec3f rotateAroundY_rad(Vec3f const &v, float angleRadians);
Vec3f rotateAroundZ_rad(Vec3f const &v, float angleRadians);
//

Vec3f componentMultiplication(Vec3f lhs, Vec3f const &rhs);
Vec3f componentDivision(Vec3f lhs, Vec3f const &rhs);

Vec3f projectOnto(Vec3f const &inputVector, Vec3f const &axis);
Vec3f zeroX(Vec3f const &inputVector);
Vec3f zeroY(Vec3f const &inputVector);
Vec3f zeroZ(Vec3f const &inputVector);

Vec3f orthogonalize(Vec3f inputVector, Vec3f const &axis);

Vec3f arbitraryOrthogonalTo(Vec3f const &vec);

float angleBetween(math::Vec3f const &u, math::Vec3f const &v);

Vec3f minComponents(Vec3f const &l, Vec3f const &r);
Vec3f maxComponents(Vec3f const &l, Vec3f const &r);

// TODO move elsewhere
math::Vec3f tangentToSphere(math::Vec3f const &p,
                            math::Vec3f const &otherPoint);
math::Vec3f stepAlongSphere(float t, math::Vec3f const &n,
                            math::Vec3f const &v);

std::istream &operator>>(std::istream &in, Vec3f &v);
std::ostream &operator<<(std::ostream &out, Vec3f const &v);

} // namespace math
