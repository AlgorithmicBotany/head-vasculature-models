#include "vec3f.h"

#include <cmath>
#include <iostream>

#include "math_utility.h"

namespace math {

// Member function interface
// TODO added to appese clang: initialized {0,0,0} bug
Vec3f::Vec3f() : x(0.f), y(0.f), z(0.f) {}

Vec3f::Vec3f(float all) : Vec3f(all, all, all) {}

Vec3f::Vec3f(float x, float y, float z) : x(x), y(y), z(z) {}

Vec3f &Vec3f::operator+=(Vec3f const &rhs) {
  x += rhs.x;
  y += rhs.y;
  z += rhs.z;
  return *this;
}
Vec3f &Vec3f::operator-=(Vec3f const &rhs) {
  x -= rhs.x;
  y -= rhs.y;
  z -= rhs.z;
  return *this;
}

Vec3f &Vec3f::operator*=(float rhs) {
  x *= rhs;
  y *= rhs;
  z *= rhs;
  return *this;
}

Vec3f &Vec3f::operator/=(float rhs) {
  x /= rhs;
  y /= rhs;
  z /= rhs;
  return *this;
}

float &Vec3f::operator[](size_t id) { return coord[id]; }

float const &Vec3f::operator[](size_t id) const { return coord[id]; }

float *Vec3f::data() { return &coord[0]; }

float const *Vec3f::data() const { return &coord[0]; }

Vec3f &Vec3f::normalize() {
  float l = norm(*this);
  return (*this) /= l;
}

// Free function

namespace vec3f {
Vec3f from(Vec2f const &v) { return {v.x, v.y, 0.f}; }
} // namespace vec3f

namespace vec2f {
Vec2f from(Vec3f const &v) { return {v.x, v.y}; }
} // namespace vec2f

/*
 * Vector-Vector Addition/ Subtraction
 */

Vec3f operator+(Vec3f const &a, Vec3f const &b) {
  return Vec3f(a.x + b.x, a.y + b.y, a.z + b.z);
}
Vec3f operator-(Vec3f const &a, Vec3f const &b) {
  return Vec3f(a.x - b.x, a.y - b.y, a.z - b.z);
}

/*
 * Scalar-Vector Multiplication/Division
 */
Vec3f operator*(float s, Vec3f v) {
  v.x *= s;
  v.y *= s;
  v.z *= s;
  return v;
}
Vec3f operator*(Vec3f v, float s) { return s * v; }

Vec3f operator/(Vec3f v, float s) {
  v.x /= s;
  v.y /= s;
  v.z /= s;
  return v;
}

/*
 * Negation of vector
 * -v = (-1.f) * v
 */
Vec3f operator-(Vec3f v) {
  v.x = -v.x;
  v.y = -v.y;
  v.z = -v.z;
  return v;
}

/*
 * Vector-Vector (inner/dot) product
 */
float operator*(Vec3f const &a, Vec3f const &b) {
  return a.x * b.x + a.y * b.y + a.z * b.z;
}
float dot(Vec3f const &a, Vec3f const &b) { return a * b; }

/*
 * Vector-Vector cross product
 */
Vec3f operator^(Vec3f const &a, Vec3f const &b) {
  return Vec3f(a.y * b.z - a.z * b.y, a.z * b.x - a.x * b.z,
               a.x * b.y - a.y * b.x);
}
Vec3f cross(Vec3f const &a, Vec3f const &b) { return a ^ b; }

/*
 * Vector norm (length)
 */
float norm(Vec3f const &v) {
  return std::sqrt(v.x * v.x + v.y * v.y + v.z * v.z);
}
float normSquared(Vec3f const &v) { return v.x * v.x + v.y * v.y + v.z * v.z; }

// synonyms of norm and normSquared
//(helps with symmantic expression and templates)
float length(Vec3f const &v) { return norm(v); }
float lengthSquared(Vec3f const &v) { return normSquared(v); }

bool operator<(Vec3f const &a, Vec3f const &b) {
  if (b.x < a.x)
    return false;
  if (b.y < a.y)
    return false;
  if (b.z < a.z)
    return false;
  return true;
}

/*
 * Normalized Vector
 */
Vec3f normalized(Vec3f v) {
  float l = norm(v);
  return v /= l;
}

/*
 * Linear interpolation
 */
Vec3f lerp(Vec3f const &a, Vec3f const &b, float t) {
  return (1.f - t) * a + t * b;
}

Vec3f mid(Vec3f const &a, Vec3f const &b) { return 0.5f * (a + b); }

float distance(Vec3f const &a, Vec3f const &b) { return norm(a - b); }

float distanceSquared(Vec3f const &a, Vec3f const &b) {
  return normSquared(a - b);
}

// DEGREES

Vec3f rotateAroundAxis(Vec3f const &v, Vec3f axis, float degrees) {
  // Rodrigues formula
  // rotates a vector around an arbitrary axis by an angle (degrees)
  axis.normalize();

  return rotateAroundNormalizedAxis(v, axis, degrees);
}

Vec3f rotateAroundNormalizedAxis(Vec3f const &v, Vec3f const &axis,
                                 float degrees) {
  // Rodrigues formula
  // rotates a vector around an arbitrary axis by an angle (degrees)

  auto angle = math::degreeToRadian(degrees);
  float const sinTheta = std::sin(angle);
  float const cosTheta = std::cos(angle);

  return v * cosTheta + (axis ^ v) * sinTheta +
         axis * ((axis * v) * (1.f - cosTheta));
}

Vec3f rotateAroundX(Vec3f const &v, float degrees) {
  return rotateAroundNormalizedAxis(v, math::axis3::X, degrees);
}
Vec3f rotateAroundY(Vec3f const &v, float degrees) {
  return rotateAroundNormalizedAxis(v, math::axis3::Y, degrees);
}
Vec3f rotateAroundZ(Vec3f const &v, float degrees) {
  return rotateAroundNormalizedAxis(v, math::axis3::Z, degrees);
}

// RADIANS
Vec3f rotateAroundAxis_rad(Vec3f const &v, Vec3f axis, float radians) {
  // Rodrigues formula
  // rotates a vector around an arbitrary axis by an angle (radians)
  axis.normalize();
  return rotateAroundNormalizedAxis(v, axis, radians);
}

Vec3f rotateAroundNormalizedAxis_rad(Vec3f const &v, Vec3f const &axis,
                                     float radians) {
  // Rodrigues formula
  // rotates a vector around an arbitrary axis by an angle (degrees)

  float const sinTheta = std::sin(radians);
  float const cosTheta = std::cos(radians);

  return v * cosTheta + (axis ^ v) * sinTheta +
         axis * ((axis * v) * (1.f - cosTheta));
}

Vec3f rotateAroundX_rad(Vec3f const &v, float radians) {
  return rotateAroundNormalizedAxis_rad(v, math::axis3::X, radians);
}
Vec3f rotateAroundY_rad(Vec3f const &v, float radians) {
  return rotateAroundNormalizedAxis_rad(v, math::axis3::Y, radians);
}
Vec3f rotateAroundZ_rad(Vec3f const &v, float radians) {
  return rotateAroundNormalizedAxis_rad(v, math::axis3::Z, radians);
}

Vec3f componentMultiplication(Vec3f lhs, const Vec3f &rhs) {
  lhs[0] *= rhs[0];
  lhs[1] *= rhs[1];
  lhs[2] *= rhs[2];
  return lhs;
}

Vec3f componentDivision(Vec3f lhs, const Vec3f &rhs) {
  lhs[0] /= rhs[0];
  lhs[1] /= rhs[1];
  lhs[2] /= rhs[2];
  return lhs;
}

Vec3f projectOnto(Vec3f const &v, Vec3f const &a) {
  return ((v * a) / (a * a)) * a;
}

Vec3f reflect(Vec3f const &v, Vec3f const &normal) {
  return v - 2.f * projectOnto(v, normal);
}

Vec3f zeroX(Vec3f const &v) { return {0.f, v.y, v.z}; }

Vec3f zeroY(Vec3f const &v) { return {v.x, 0.f, v.z}; }

Vec3f zeroZ(Vec3f const &v) { return {v.x, v.y, 0.f}; }

Vec3f orthogonalize(Vec3f v, Vec3f const &a) { return v -= projectOnto(v, a); }

Vec3f arbitraryOrthogonalTo(Vec3f const &v) {
  math::Vec3f perp(0.f, 0.f, 0.f);
  constexpr int X = 0;
  constexpr int Y = 1;
  constexpr int Z = 2;
  auto minimumDimension = math::minimum(X, Y, Z, [&](uint32_t a, uint32_t b) {
    return (std::abs(v[a]) < std::abs(v[b]) ? a : b);
  });
  perp[minimumDimension] = 1.f; // pick the "most" orthogonal dimension
  return orthogonalize(perp, v);
}

float angleBetween(math::Vec3f const &u, math::Vec3f const &v) {
  // https://possiblywrong.wordpress.com/2020/07/17/computing-the-angle-between-two-vectors/
  float nu = math::norm(u);
  float nv = math::norm(v);
  return 2.f *
         std::atan2(math::norm(nv * u - nu * v), math::norm(nv * u + nu * v));
}

Vec3f maxComponents(Vec3f const &l, Vec3f const &r) {
  using std::max;
  return {max(l.x, r.x), //
          max(l.y, r.y), //
          max(l.z, r.z)};
}

Vec3f minComponents(Vec3f const &l, Vec3f const &r) {
  using std::min;
  return {min(l.x, r.x), //
          min(l.y, r.y), //
          min(l.z, r.z)};
}

math::Vec3f tangentToSphere(math::Vec3f const &p,
                            math::Vec3f const &otherPoint) {
  return math::normalized(math::orthogonalize(otherPoint, math::normalized(p)));
}

math::Vec3f stepAlongSphere(float t, math::Vec3f const &n,
                            math::Vec3f const &v) {
  auto speed = math::norm(v);
  if (speed < 0.0001f)
    return n;

  return std::cos(speed * t) * n + (std::sin(speed * t) / speed) * v;
}

std::ostream &operator<<(std::ostream &out, Vec3f const &v) {
  return out << v.x << " " << v.y << " " << v.z;
}

std::istream &operator>>(std::istream &in, Vec3f &v) {
  return in >> v.x >> v.y >> v.z;
}

} // namespace math
