#include "timestamp_primordia_file_io.h"

#include <algorithm>
#include <fstream>
#include <iostream>
#include <iterator>

#include "enum_utility.h"

namespace modelling {
namespace phyllotaxis {

std::istream &operator>>(std::istream &in, TimestampPrimordia &t) {
  return in >> t.id     //
         >> t.timestamp //
         >> t.fraction  //
         >> t.angle     //
         >> t.radius    // TODO fix in other models
         >> t.type;
}
std::istream &operator>>(std::istream &in, TimestampPrimordia::Type &t) {
  auto v = utility::valueOf(t);
  in >> v;
  t = TimestampPrimordia::Type(v);
  return in;
}

std::ostream &operator<<(std::ostream &out, TimestampPrimordia const &t) {

  auto v = utility::valueOf(t.type);
  return out << t.id << ' '        //
             << t.timestamp << ' ' //
             << t.fraction << ' '  //
             << t.angle << ' '     //
             << t.radius << ' '    // TODO fix in other models
             << v;
}

std::vector<TimestampPrimordia> gatherTimestampPrimordiaBetween(
    uint32_t timeA, uint32_t timeB,
    std::vector<TimestampPrimordia> const &primordia) {
  std::vector<TimestampPrimordia> out;

  if (timeB < timeA)
    return out;

  struct Compare {
    bool operator()(TimestampPrimordia const &prim, uint32_t time) const {
      return prim.timestamp < time;
    }
    bool operator()(uint32_t time, TimestampPrimordia const &prim) const {
      return time < prim.timestamp;
    }
  };

  using namespace std;
  auto lo = lower_bound(begin(primordia), end(primordia), timeA, Compare{});
  auto hi = upper_bound(begin(primordia), end(primordia), timeB - 1, Compare{});

  out.reserve(distance(lo, hi));
  copy(lo, hi, back_inserter(out));

  return out;
}

std::vector<TimestampPrimordia>
readTimestampPrimordiaFromFile(std::string const &filepath) {
  std::vector<TimestampPrimordia> primordiumOrdered;

  std::ifstream file(filepath);
  if (file.good()) {
    int numberOfPrimordia = 0;
    file >> numberOfPrimordia;

    primordiumOrdered.reserve(numberOfPrimordia);

    std::copy_n(std::istream_iterator<TimestampPrimordia>(file),
                numberOfPrimordia, std::back_inserter(primordiumOrdered));
  }

  return primordiumOrdered;
}

//
// Initial prims output from Phyllot (coming
//
std::vector<TimestampPrimordia>
fixOutOfOrder(std::vector<TimestampPrimordia> prims) {
  using namespace std;
  sort(begin(prims), end(prims),
       [](auto const &a, auto const &b) { return a.id < b.id; });

  for (int id = 1; id < prims.size(); ++id) {
    auto const &prev = prims[id - 1];
    auto &curr = prims[id];

    if (curr.timestamp < prev.timestamp) {
      curr.timestamp = prev.timestamp + 1;
    }
  }

  return prims;
}

} // namespace phyllotaxis
} // namespace modelling
