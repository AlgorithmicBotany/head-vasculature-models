#pragma once

#include <vector>

#include "math_utility.h"
#include "vec2f.h"
#include "vec3f.h"

namespace modelling {
// Volumetric (3D) simulations
math::Vec2f rotateIntoXY_Quadrants_1_4(math::Vec3f const &position);

std::vector<math::Vec2f>
projectToVolumeOfRevolutionDomain(std::vector<math::Vec3f> const &positions);

math::Vec3f
inverse_projectTo2DRevolutionFrom3D(math::Vec2f const &volumeCoordinates,
                                    math::Vec3f originalCoordinates);

void insitu_inverse_projectToVolumeOfRevolution(
    std::vector<math::Vec3f> &originalCoordinates,
    std::vector<math::Vec2f> const &volumeCoordinates);

// Flat (2D) simulations
math::Vec2f reflectIntoXY_Quadrant_1_4(math::Vec2f const &position);

math::Vec2f
inverse_projectToMirroredRegion(math::Vec2f const &volumeCoordinates,
                                math::Vec2f originalCoordinates);
std::vector<math::Vec2f>
projectToMirroredRegion(std::vector<math::Vec2f> const &positions);

void insitu_inverse_projectToMirroredRegion(
    std::vector<math::Vec2f> const &volumeCoordinates,
    std::vector<math::Vec2f> &originalCoordinates);

} // namespace modelling
