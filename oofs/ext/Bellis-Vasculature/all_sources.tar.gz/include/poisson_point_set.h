#pragma once

#include "containers_utility.h"
#include <vector>

namespace randutil {

template <class T, class MatchFunc>
bool fitsInPoissonDiskSet(T const &p, std::vector<T> const &points,
                          MatchFunc matchFunc) {
  return utility::isUniqueAmoung(p, points, matchFunc);
}

template <class T, class Generator, class MatchFunc>
std::vector<T> generatePoissonDiskPointsAmoungst(std::vector<T> const &points,
                                                 int requestedPointCount,
                                                 Generator gen,
                                                 MatchFunc matchFunc,
                                                 int MAX_ATTEMPTS = 1000) {
  std::vector<T> newPoints;
  newPoints.reserve(requestedPointCount);

  int attemptCounter{0};

  do {
    auto p = gen();
    if (fitsInPoissonDiskSet(p, points, matchFunc)) {
      newPoints.push_back(p);
      attemptCounter = 0; // reset
    } else {
      attemptCounter++;
    }
  } while (newPoints.size() < requestedPointCount &&
           attemptCounter < MAX_ATTEMPTS);

  return newPoints;
}

} // namespace randutil
