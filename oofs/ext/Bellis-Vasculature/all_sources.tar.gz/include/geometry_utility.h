#pragma once

#include "math_utility.h"

namespace geometry {

template <class Type> struct Distant {
  Type data;
  float distance = math::maxValue<float>();
};

template <class Vec>
float distanceToLineSegment(Vec const &a, Vec const &b, Vec const &p) {
  auto ab = b - a;
  auto ap = p - a;

  auto t = dot(ab, ap) / dot(ab, ab);

  if (t <= 0.f)
    return distance(p, a);
  if (t >= 1.f)
    return distance(p, b);

  auto w = ap - t * ab;
  return length(w);
}

template <class Vec>
Vec closestToLineSegment(Vec const &a, Vec const &b, Vec const &p) {
  auto ab = b - a;
  auto ap = p - a;

  auto t = dot(ab, ap) / dot(ab, ab);

  if (t <= 0.f)
    return a;
  if (t >= 1.f)
    return b;

  return a + t * ab;
}

template <class Vec>
float distanceToInfinteLine(Vec const &origin, Vec const &dir, Vec const &p) {
  auto op = p - origin;

  auto t = dot(dir, op) / dot(dir, dir);
  auto w = op - t * dir;

  return length(w);
}

template <class Vec>
Vec projectOntoTriangleEdges(Vec const &a, Vec const &b, Vec const &c,
                             Vec const &p) {
  auto ab = distanceToLineSegment(a, b, p);
  auto bc = distanceToLineSegment(b, c, p);
  auto ca = distanceToLineSegment(c, a, p);

  if (ab < bc) {
    if (ab < ca)
      return closestToLineSegment(a, b, p);
    else
      return closestToLineSegment(c, a, p);
  } else {
    if (bc < ca)
      return closestToLineSegment(b, c, p);
    else
      return closestToLineSegment(c, a, p);
  }
}

} // namespace geometry
