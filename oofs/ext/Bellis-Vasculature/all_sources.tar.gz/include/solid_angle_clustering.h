#pragma once

#include <vector>

#include "vec3f.h"

namespace clustering {

struct SpherePoint {
  math::Vec3f p; // point on sphere
  float w;       // weight
};

using SolidAngleCluster = std::vector<SpherePoint>;

SolidAngleCluster
selectSolidAngleClusterAround(math::Vec3f const &p,
                              std::vector<math::Vec3f> const &points,
                              float baseSolidAngle, float maxSolidAngle);

} // namespace clustering
