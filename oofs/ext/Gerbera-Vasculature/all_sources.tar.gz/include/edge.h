#pragma once

#include <vector>

namespace geometry {

template <typename T> struct Edge {
  union {
    struct {
      T a;
      T b;
    };
    T vertex[2];
  };

  Edge() : a(T{0}), b(T{0}) {}
  Edge(T a, T b) : a(a), b(b) {}
};

} // namespace geometry
