#include "edge.h"

namespace geometry {} // namespace geometry
