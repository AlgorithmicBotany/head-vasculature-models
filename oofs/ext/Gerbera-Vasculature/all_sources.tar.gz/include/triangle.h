//
//  triangle.h
//  Triangle
//  CollisionExample
//
//  Created by Andrew Owens
//  Copyright (c) 2018 ___ALGORITHMIC_BOTANY___. All rights reserved.
//

#pragma once

namespace geometry {

template <typename T> struct Triangle {
  Triangle() = default;
  union {
    struct {
      T a;
      T b;
      T c;
    };
    T vertex[3];
  };
};

template <typename T>
bool isPartOfTriangle(geometry::Triangle<T> const &triangle, T const &elem) {
  return (triangle.a == elem) || (triangle.b == elem) || (triangle.c == elem);
}

} // namespace geometry
