#include <fstream>
#include <iostream>
#include <sstream>

float cval(char const *name) {

  std::fstream panel("./panel.vset");

  if (!panel) {
    std::cerr << "Warning: did not find " << name << '\n';
    return 0.f;
  }

  std::string line;
  std::string token;
  while (getline(panel, line)) {
    std::size_t found = line.find(name);
    if (found == std::string::npos)
      continue;

    std::stringstream ss(line);
    std::string hash;
    std::string name;
    float value;
    ss >> hash >> name >> value;

    return value;
  }

  return 0.f;
}
