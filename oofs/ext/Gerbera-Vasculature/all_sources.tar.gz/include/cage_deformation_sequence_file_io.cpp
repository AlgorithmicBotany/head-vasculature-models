#include "cage_deformation_sequence_file_io.h"

#include <fstream>
#include <iostream>

namespace modelling {

void insitu_readMeshCageFromBinaryStream(MeshCage &cage, std::istream &in) {
  // VERTICES
  // vertex count
  uint32_t vertCount;
  in.read((char *)&vertCount, sizeof(uint32_t));

  auto &verts = cage.mesh.vertices();
  verts.resize(vertCount);
  in.read((char *)verts.data(), sizeof(MeshCage::Mesh::vertex_t) * vertCount);

  // FACES
  // # of faces
  uint32_t faceCount;
  in.read((char *)&faceCount, sizeof(uint32_t));

  auto &faces = cage.mesh.triangles();
  faces.resize(faceCount);
  in.read((char *)faces.data(), sizeof(MeshCage::Mesh::triangle_t) * faceCount);

  // CONTROL POINTS
  // # of control points
  uint32_t cpCount;
  in.read((char *)&cpCount, sizeof(uint32_t));

  auto &cps = cage.controlPoints.points();
  cps.resize(cpCount);
  in.read((char *)cps.data(), sizeof(math::Vec2f) * cpCount);

  // FIELD VALUES
  auto &fields = cage.controlPointFields;
  fields.resize(cpCount);

  for (auto &w : fields) {
    w.resize(vertCount);
    in.read((char *)w.data(), sizeof(float) * w.size());
  }
}

//std::optional<MeshCageDeformation>
nonstd::optional<MeshCageDeformation>
readMeshCageDeformationFromBinaryFile(std::string const &filePath) {
  using namespace std;

  MeshCageDeformation cageDeformation;
  ifstream fileIn(filePath, ios::in | ios::binary);

  if (!fileIn) {
    std::cerr << "[ERROR] could not open cage deformation file " << filePath
              << std::endl;
    return nonstd::nullopt;
  }

  // # of deformations
  uint32_t deformationCount = 0;
  fileIn.read((char *)&deformationCount, sizeof(uint32_t));

  cageDeformation.resize(deformationCount);

  for (auto &cage : cageDeformation) {
    insitu_readMeshCageFromBinaryStream(cage, fileIn);
  }

  return cageDeformation;
}

// void insitu_readControurFieldGrowthFromFile(MeshCageDeformation &meshes,
//                                            std::string const &binaryFilePath)
//                                            {
//  if (meshes.empty()) {
//    insitu_readMeshCageDeformationFromBinaryFile(meshes, binaryFilePath);
//  }
//}

} // namespace modelling
