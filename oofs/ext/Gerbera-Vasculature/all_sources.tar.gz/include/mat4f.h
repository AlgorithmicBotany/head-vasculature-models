#pragma once

#include <array>
#include <initializer_list>
#include <iosfwd>

#include "vec4f.h"

namespace math {

class Mat4f {
public:
  enum { DIMENSION = 4, NUMBER_ELEMENTS = 16 };

  using array16f = std::array<float, NUMBER_ELEMENTS>;
  using iterator = array16f::iterator;
  using const_iterator = array16f::const_iterator;

public:
  Mat4f() = default;
  explicit Mat4f(float fillValue);
  explicit Mat4f(array16f values);
  Mat4f(math::Vec4f const &row0, math::Vec4f const &row1,
        math::Vec4f const &row2, math::Vec4f const &row3);
  Mat4f(std::initializer_list<float> list);

  Mat4f &operator+=(Mat4f const &);
  Mat4f &operator-=(Mat4f const &);
  Mat4f &operator*=(Mat4f const &);

  void fill(float t);

  float &operator()(int row, int column);
  float &operator[](int element);
  float &at(int row, int column);
  float &at(int element);
  float *data();

  float operator()(int row, int column) const;
  float operator[](int element) const;
  float at(int row, int column) const;
  float at(int element) const;
  float const *data() const;

  iterator begin();
  iterator end();
  const_iterator begin() const;
  const_iterator end() const;

  static int rowMajorIndex(int row, int column);

private:
  array16f m_values;
};

namespace mat4f {
Mat4f identity();
}

Mat4f fromColumns(math::Vec4f const &c0, math::Vec4f const &c1,
                  math::Vec4f const &c2, math::Vec4f const &c3);

Mat4f transposed(Mat4f m);
float determinant(Mat4f const &m);
Mat4f inverse(Mat4f const &m);

Mat4f operator+(Mat4f const &lhs, Mat4f const &rhs);
Mat4f operator-(Mat4f const &lhs, Mat4f const &rhs);
Mat4f operator*(Mat4f const &lhs, Mat4f const &rhs);
Mat4f operator*(float s, Mat4f rhs);
Mat4f operator*(Mat4f lhs, float s);

Vec4f operator*(Mat4f const &lhs, Vec4f const &rhs);

std::ostream &operator<<(std::ostream &out, Mat4f const &mat);

void printMatrix(math::Mat4f const &m);

} // namespace math
