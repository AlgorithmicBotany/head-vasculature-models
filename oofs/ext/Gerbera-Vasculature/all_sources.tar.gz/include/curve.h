#pragma once

#include <algorithm>
#include <iterator>
#include <utility>
#include <vector>

#include "vec2f.h"
#include "vec3f.h"

namespace geometry {

template <class Point> class Curve {
public: // types
  using point_t = Point;
  using point_store = std::vector<point_t>;
  using iterator = typename point_store::iterator;
  using const_iterator = typename point_store::const_iterator;

public: // methods
  Curve() = default;
  Curve(point_store points) : m_points(points) {}

  template <class... Args> void append(Args... args) {
    m_points.emplace_back(std::forward<Args>(args)...);
  }

  void insert(uint32_t index, point_t v) {
    m_points.insert(begin() + index, v);
  }

  void removeBack() { m_points.pop_back(); }

  point_t operator()(float t) const {
    // TODO fill with better function
    if (size() == 0)
      return point_t();

    if (size() == 1)
      return front();

    if (t >= 1.f)
      return front();

    // For now just find closest point
    auto index = t * size();
    return m_points[index];
  }

  void points(point_store points) { std::swap(points, m_points); }
  point_store const &points() const { return m_points; }
  point_store &points() { return m_points; }

  uint32_t size() const { return m_points.size(); }

  point_t operator[](uint32_t index) const { return m_points[index]; }
  point_t &operator[](uint32_t index) { return m_points[index]; }

  point_t &front() { return m_points.front(); }
  point_t front() const { return m_points.front(); }

  point_t &back() { return m_points.back(); }
  point_t back() const { return m_points.back(); }

  iterator begin() { return m_points.begin(); }
  iterator end() { return m_points.end(); }
  const_iterator begin() const { return m_points.begin(); }
  const_iterator end() const { return m_points.end(); }

private: // member variables
  point_store m_points;
};

template <class Point>
Curve<Point> interpolate(Curve<Point> curveA,        //
                         Curve<Point> const &curveB, //
                         float t) {
  uint32_t index = 0;
  for (auto &a : curveA) {
    a = math::lerp(a, curveB[index++]);
  }

  return curveA;
}

template <class Point> Curve<Point> reverse(Curve<Point> curve) {
  std::reverse(std::begin(curve), std::end(curve));
  return curve;
}

template <class Point> float length(Curve<Point> const &curve) {
  if (curve.size() < 2)
    return 0.f;

  auto iter = std::begin(curve);
  auto next = std::next(iter);

  float length = 0.f;
  for (; next != std::end(curve); ++iter, ++next) {
    length += distance(*iter, *next);
  }
  return length;
}

// index based stuff
template <class Point>
float indexArcLength(Curve<Point> const &curve, int pointIndex) {
  if (curve.size() < 2)
    return 0.f;

  float length = 0.f;
  for (int index = 0; index < pointIndex; ++index) {
    length += distance(curve[index], curve[index + 1]);
  }

  return length;
}

template <class Point>
int indexAtArcLength(Curve<Point> const &curve, float s) {

  int index = 0;

  float accum = 0.f;
  while (accum < s) {
    auto a = curve[index];
    auto b = curve[index + 1];

    accum += math::distance(a, b);

    ++index;
  }

  return index;
}

template <class Point>
float partitionLength(Curve<Point> const &curve, int start, int end) {
  if (curve.size() < 2)
    return 0.f;

  float length = 0.f;
  for (; start + 1 != end; ++start) {
    length += distance(curve[start], curve[start + 1]);
  }

  return length;
}

template <class Point>
Point positionAlongCurvePartition(Curve<Point> const &curve, int start, int end,
                                  float t) {

  float const distance = partitionLength(curve, start, end) * t;

  float accum = 0.f;
  int segmentA = start, segmentB = start + 1;

  bool foundSegment = false;
  while (!foundSegment && start != end) {
    auto a = curve[segmentA];
    auto b = curve[segmentB];

    accum += math::distance(a, b);

    if (accum >= distance) {
      foundSegment = true;
    } else {
      segmentA = segmentB;
      ++segmentB;
    }
  }

  auto a = curve[segmentA];
  auto b = curve[segmentB];

  float deltaDist = accum - distance;
  t = deltaDist / math::distance(a, b);

  return t * a + (1.f - t) * b;
}

template <class Point>
int indexAlongCurvePatition(Curve<Point> const &curve, int start, int end,
                            float t) {

  float const distance = partitionLength(curve, start, end) * t;

  float accum = 0.f;
  int segmentA = start, segmentB = start + 1;

  bool foundSegment = false;
  while (!foundSegment && start != end) {
    auto a = curve[segmentA];
    auto b = curve[segmentB];

    accum += math::distance(a, b);

    if (accum >= distance) {
      foundSegment = true;
    } else {
      segmentA = segmentB;
      ++segmentB;
    }
  }

  return segmentB;
}

template <class Point>
Curve<Point> subdivide(Curve<Point> curve, int totalSubdivisions) {

  typename Curve<Point>::point_store tmp;
  typename Curve<Point>::point_store &points = curve.points();

  for (short count = 0; count < totalSubdivisions; ++count) {
    tmp.reserve(2 * points.size());

    for (int i = 0; i < points.size() - 1; ++i) {
      auto a = points[i];
      auto b = points[i + 1];

      tmp.push_back(a);
      tmp.push_back(0.5f * (a + b));
    }

    tmp.push_back(points.back());

    points.swap(tmp);
    tmp.clear();
  }

  return curve;
}

template <typename T>
std::vector<T> sampleBetween(T const &a, T const &b, int samples) {
  std::vector<T> tmp;
  tmp.reserve(samples);

  float dt = 1.f / (samples - 1); // fence post

  tmp.push_back(a);

  for (int sample = 1; sample < (samples - 1); ++sample) {
    tmp.push_back(math::lerp(a, b, sample * dt));
  }

  tmp.push_back(b);

  return tmp;
}

template <typename Curve> Curve reverse(Curve curve) {
  std::reverse(std::begin(curve.points()), std::end(curve.point()));
  return curve;
}

template <typename Curve>
Curve subCurvePartition(Curve const &curve, int start, int end) {
  Curve out;
  out.points().reserve(std::abs(end - start));

  for (int id = start; id < end; ++id) {
    out.append(curve[id]);
  }
  return out;
}

template <class Curve>
std::vector<typename Curve::point_t> arclengthSample(Curve const &curve,
                                                     float ds) {
  std::vector<typename Curve::point_t> out;
  // calculate length
  float accum{0.f};
  out.push_back(curve.front());
  for (int id = 1; id < curve.size(); ++id) {
    auto const &a = curve[id - 1];
    auto const &b = curve[id];

    accum += math::distance(a, b);
    if (accum >= ds) {
      out.push_back(b);
      accum -= ds;
    }
  }

  out.push_back(curve.back());
  return out;
}

using Curve2f = Curve<math::Vec2f>;
using Curve3f = Curve<math::Vec3f>;

Curve2f mirrorContourHorizontally(Curve2f const &curve);

Curve3f mirrorContourOnYZPlane(Curve3f const &curve);

Curve2f offsetContour(Curve2f const &curve, float offset);

Curve2f sampleLine(math::Vec2f a, math::Vec2f b, uint32_t sampleCount);

Curve3f make3D(Curve2f const &curve);

} // namespace geometry
