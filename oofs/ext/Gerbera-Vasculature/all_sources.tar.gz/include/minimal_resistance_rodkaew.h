#pragma once

#include "directed_graph.h"
#include "vec3f.h"

namespace vasculature {

struct MinimalResistanceRodkaew {
  struct Node {

    math::Vec3f position;
    math::Vec3f direction;

    // computation
    float distanceToBase{0.f};
    float resistanceAtNode{0.f};    // local to node
    float effectiveResistance{0.f}; // global to base

    int age{0};

    enum class Type : int { FLORET = 0, ABAXIAL, ADAXIAL };
    Type type{Type::FLORET};
    float baseResistance{1.f}; // based on type

    // visualization
    float width{1.f};

    // debug
    int id{-1};
    std::vector<Node *> closestNeighs;
    std::vector<Node *> oldestNeighs;
    std::vector<Node *> minSelect;
  };
  using NodeType = Node::Type;
  using Vasculature = geometry::DirectedGraph<MinimalResistanceRodkaew::Node>;
  using DiffuseAuxinPoints = std::vector<math::Vec3f>;
};

void stepVascularAge(MinimalResistanceRodkaew::Vasculature &veins,
                     float r_groundTissue, float r_vascular,
                     int veinAgeFullyGrown);

void acropetal_recalculateVascularResistances(
    MinimalResistanceRodkaew::Vasculature &veins,
    MinimalResistanceRodkaew::Vasculature::node_refs const &sinks);

MinimalResistanceRodkaew::Vasculature::node_ptr
growVeinInitialOrthogonalToReceptical(
    MinimalResistanceRodkaew::Vasculature::node_ptr tip,
    MinimalResistanceRodkaew::Vasculature &veins, float stepDistance,
    float veinJitterStrength, float veinJitterFrequency);

// rodkaew - like
void growMinimalResistancePathVeins(
    MinimalResistanceRodkaew::Vasculature &veins,
    MinimalResistanceRodkaew::Vasculature::node_refs const &veinTips,
    float r_groundTissue, float mergeDistance, float stepDistance,
    float veinJitterFrequency, float veinJitterStrength,
    float sectorialPropensity, float shieildingSolidAngle);

// space colonization - like
MinimalResistanceRodkaew::Vasculature::node_refs
growDiffuseVeins(MinimalResistanceRodkaew::Vasculature &veins,
                 MinimalResistanceRodkaew::DiffuseAuxinPoints &diffuseAuxin,
                 float r_groundTissue, float mergeDistance, float stepDistance,
                 float veinJitterFrequency, float veinJitterStrength,
                 float sectorialPropensity, float killDistance);

float sectorialResistivityFactor(math::Vec3f const &tip,
                                 math::Vec3f const &point,
                                 float sectorialPropensity);

MinimalResistanceRodkaew::Vasculature::node_refs processReticulateNodes(
    MinimalResistanceRodkaew::Vasculature &dag,
    MinimalResistanceRodkaew::Vasculature::node_refs
        &reticulateNodesToBeProcessed,
    MinimalResistanceRodkaew::Vasculature::node_refs &reticulateNodes,
    float mergeDistance, float stepDistance, float veinJitterFrequency,
    float veinJitterStrength, float sectorialPropensity,
    float reticulationPropensity, float r_ground, int reticulationAgeTrigger);

} // namespace vasculature
