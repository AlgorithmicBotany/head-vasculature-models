#pragma once

#include "containers_utility.h"
#include "edge.h"
#include "vec3f.h"

#include <cassert>
#include <memory>
#include <queue>
#include <unordered_map>
#include <vector>

//
// Node * are NON-Owner handles (random number ids haha) to memory managed by
// the graph. Parents/children are NON-Owner handles as well.
// node->disconnectAll() is called by graph releaseNode/deleteNode, so topology
// and pointers are handleds as well.
//
// Graph Currently only creates nodes, however deletion may on
// structure I wanted a simple local interface for node adoption/orphaning auto
// node = graph.addNode(...);
// ...
// node->adopt(other);
// other->orphan(yetAnother);
// ....
// Very likely not thread-safe haha, but easy to use
//
// reason:
// Unique_ptrs are preferable, however, when iterating using begin()
// end(), they return const & (unless we wrap an iterator, a viable option) and
// if we wish to add new nodes while iterating (not ideal, but possible), both
// the iterators and & could be invalidated. Forcing the user to call .get() on
// the const & is not ideal either.
// Our policy: Node * are non-owning handles into memory,
// owend by the DataStruct. Most of the code (rule of 5) is here anyways
//
// warning:
// Pointers passed in deleteNode or releaseNode invalidate (i.e., null) the
// pointer passed in, BUT any other copies of that pointer outside the graph
// still points to invalid memory.
//
// I know this is somewhat dangerous, but I like the simple interface
//

namespace geometry {

//
// Directed Graph (data at vertices)
//

template <class Data> struct DirectedGraph {
  using value_t = Data;

  //
  // Node type
  //
  struct Node final {
    value_t data;
    using ptr_t = Node *;
    using ptr_store = std::vector<ptr_t>;

    Node() = default;

    template <class... Args>
    Node(Args &&...args) : data(std::forward<Args>(args)...) {}

    Node(value_t data) : data(std::move(data)) {}

    ptr_store const &parents() const { return m_parents; }
    ptr_store const &children() const { return m_children; }

    bool isLeaf() const { return !hasChildren(); }

    bool hasParents() const { return !m_parents.empty(); }
    bool hasChildren() const { return !m_children.empty(); }

    bool isLinkedTo(Node *child) const {
      return utility::contains(child, children()) &&
             utility::contains(this, child->parents());
    }

    bool isDisconnected() const { return !hasParents() && !hasChildren(); }

    // Sole way to two-way connnect
    bool adopt(Node *child) {
      if (child == nullptr) // valid
        return false;

      if (isLinkedTo(child)) // is not already linked
        return false;

      m_children.push_back(child);
      child->m_parents.push_back(this);
      return true;
    }
    // Sole way to two-way disconnect
    bool orphan(Node *child) {
      if (child == nullptr) // valid
        return false;

      if (!isLinkedTo(child)) // is already connected (redundant, since next
                              // remove will check)
        return false;

      utility::remove(child, m_children);
      utility::remove(this, child->m_parents);
      return true;
    }
    // May only be deleted in graph if disconnected from all
    void disconnectFromAll() {

      auto childrenCopy = children(); // make copy to iterate over
      for (auto child : childrenCopy) {
        this->orphan(child);
      }

      auto parentsCopy = parents(); // make copy to iterate over
      for (auto parent : parentsCopy) {
        parent->orphan(this);
      }
    }

  private:
    ptr_store m_parents;
    ptr_store m_children;
  };

  //
  // Directed Graph
  //

  using node_ptr = Node *;
  using node_refs = typename Node::ptr_store;

  // using node_store = utility::Unique_ptrVector<Node>;
  using node_store = typename Node::ptr_store;

  using iterator = typename node_store::iterator;
  using const_iterator = typename node_store::const_iterator;

  DirectedGraph() = default;
  virtual ~DirectedGraph() { cleanup(); }

  DirectedGraph(DirectedGraph const &src) {
    DirectedGraph tmp = src.clone();
    *this = std::move(tmp);
  }
  DirectedGraph(DirectedGraph &&src) noexcept { swap(*this, src); }

  DirectedGraph &operator=(DirectedGraph const &src) {
    if (this == &src)
      return *this;
    *this = std::move(DirectedGraph{src});
    return *this;
  }
  DirectedGraph &operator=(DirectedGraph &&src) noexcept {
    swap(*this, src);
    return *this;
  }

  DirectedGraph clone() const {
    DirectedGraph graph;

    std::unordered_map<node_ptr, node_ptr> oldToNew;
    // zipper together
    for (auto node : m_nodes) {
      auto new_node = graph.addNode(node->data);
      oldToNew[node] = new_node;
    }

    for (auto node : m_nodes) {
      auto new_node = oldToNew[node];
      for (auto child : node->children()) {
        auto new_child = oldToNew[child];
        new_node->adopt(new_child);
      }
    }

    return graph;
  }

  friend void swap(DirectedGraph &a, DirectedGraph &b) noexcept {
    using std::swap;
    swap(a.m_nodes, b.m_nodes);
  }

  node_ptr operator[](size_t id) const { return m_nodes[id]; }

  template <class... Args> node_ptr addNode(Args &&...args) {
    auto node = createNode(std::forward<Args>(args)...);
    return node;
  }

  void deleteNode(node_ptr &node) {
    if (node == nullptr)
      return;
    node->disconnectFromAll();
    removeNode(node);
  }

  std::unique_ptr<Node> releaseNode(node_ptr &node) {
    if (node == nullptr)
      return {};
    node->disconnectFromAll();
    return removeNode(node);
  }

  node_store const &nodes() const { return m_nodes; }
  node_store &nodes() { return m_nodes; }

  void clear() { m_nodes.clear(); }

  iterator begin() { return std::begin(m_nodes); }
  iterator end() { return std::end(m_nodes); }

  const_iterator begin() const { return std::begin(m_nodes); }
  const_iterator end() const { return std::end(m_nodes); }

  bool empty() const { return m_nodes.empty(); }
  size_t size() const { return m_nodes.size(); }

private: // functions
  template <class... Args> node_ptr createNode(Args &&...args) {
    // strong exception guaranteed (has enough space)
    m_nodes.reserve(size() + 1);
    m_nodes.emplace_back(new Node(std::forward<Args>(args)...));

    return m_nodes.back();
  }

  std::unique_ptr<Node> removeNode(node_ptr &node) {
    assert(node->isDisconnected());

    std::unique_ptr<Node> owner{node};
    utility::remove(node, m_nodes);

    // invalidate pointer, todo wrap nodes as fatpointer structs?
    node = nullptr;

    return owner;
  }
  // needed as we are using raw pointers
  void cleanup() {
    for (auto node : m_nodes) {
      delete node;
    }
    m_nodes.clear();
  }

private:
  node_store m_nodes; // ownership
};

//
// Directed Edge data Graph (data at vertices and edges)
//

template <class Data, class EdgeData> struct DirectedEdgeDataGraph {
  using value_t = Data;
  using edge_t = EdgeData;

  //
  // Node type
  //
  struct Node final {
    value_t data;
    using ptr_t = Node *;
    using ptr_store = std::vector<ptr_t>;
    using edge_store = std::vector<edge_t>;

    Node() = default;

    template <class... Args>
    Node(Args &&...args) : data(std::forward<Args>(args)...) {}

    ptr_store const &parents() const { return m_parents; }
    ptr_store const &children() const { return m_children; }
    edge_store const &edges() const { return m_edges; }
    edge_store &edges() { return m_edges; }

    bool isLeaf() const { return !hasChildren(); }

    bool hasParents() const { return !m_parents.empty(); }
    bool hasChildren() const { return !m_children.empty(); }

    bool isLinkedTo(Node *child) const {
      return utility::contains(child, children()) &&
             utility::contains(this, child->parents());
    }

    bool isDisconnected() const { return !hasParents() && !hasChildren(); }

    // Sole way to two-way connnect
    template <class... EdgeArgs> bool  adopt(Node *child, EdgeArgs &&...args) {
      if (child == nullptr) // valid
        return false;

      if (child == this)
        return false;

      if (isLinkedTo(child)) // is not already linked
        return false;

      m_children.push_back(child);
      m_edges.emplace_back(std::forward<EdgeArgs>(args)...);

      child->m_parents.push_back(this);
      return true;
    }
    // Sole way to two-way disconnect
    bool orphan(Node *child) {
      if (child == nullptr) // valid
        return false;

      // is already connected
      //(redundant, since next remove will check)
      if (!isLinkedTo(child))
        return false;

      int index = 0;
      for (; index < m_children.size(); ++index) {
        if (m_children[index] == child)
          break;
      }

      utility::swap_pop(m_children, index);
      utility::swap_pop(m_edges, index);

      utility::remove(this, child->m_parents);
      return true;
    }

    edge_t &edgeTo(Node *neighbour) {
      int index = 0;
      for (; index < m_children.size(); ++index) {
        if (m_children[index] == neighbour)
          return m_edges[index];
      }
      index = 0;
      for (; index < m_parents.size(); ++index) {
        if (m_parents[index] == neighbour)
          return m_parents[index]->edgeTo(this);
      }

      // error : undefined behavior
      
      return m_edges[-1];
    }

    edge_t const &edgeTo(Node *neighbour) const {
      int index = 0;
      for (; index < m_children.size(); ++index) {
        if (m_children[index] == neighbour)
          return m_edges[index];
      }
      index = 0;
      for (; index < m_parents.size(); ++index) {
        if (m_parents[index] == neighbour)
          return m_parents[index]->edgeTo(this);
      }

      // error : undefined behavior
      return m_edges[-1];
    }

    // May only be deleted in graph if disconnected from all
    void disconnectFromAll() {
      disconnectFromChildren();
      disconnectFromParents();
    }

    void disconnectFromChildren() {
      auto childrenCopy = children(); // make copy to iterate over
      for (auto child : childrenCopy) {
        this->orphan(child);
      }
    }

    void disconnectFromParents() {
      auto parentsCopy = parents(); // make copy to iterate over
      for (auto parent : parentsCopy) {
        parent->orphan(this);
      }
    }

    size_t valence() const { return m_parents.size() + m_children.size(); }

  private:
    ptr_store m_parents;

    // 1-for-1, edges to children hold edge data
    ptr_store m_children;
    edge_store m_edges;
  };

  //
  // Directed Graph
  //

  using node_ptr = Node *;
  using node_refs = typename Node::ptr_store;

  // using node_store = utility::Unique_ptrVector<Node>;
  using node_store = typename Node::ptr_store;

  using iterator = typename node_store::iterator;
  using const_iterator = typename node_store::const_iterator;

  DirectedEdgeDataGraph() = default;
  virtual ~DirectedEdgeDataGraph() { cleanup(); }

  DirectedEdgeDataGraph(DirectedEdgeDataGraph const &src) {
    DirectedEdgeDataGraph tmp = src.clone();
    *this = std::move(tmp);
  }
  DirectedEdgeDataGraph(DirectedEdgeDataGraph &&src) noexcept {
    swap(*this, src);
  }

  DirectedEdgeDataGraph &operator=(DirectedEdgeDataGraph const &src) {
    if (this == &src)
      return *this;
    *this = std::move(DirectedEdgeDataGraph{src});
    return *this;
  }
  DirectedEdgeDataGraph &operator=(DirectedEdgeDataGraph &&src) noexcept {
    swap(*this, src);
    return *this;
  }

  DirectedEdgeDataGraph clone() const {
    DirectedEdgeDataGraph graph;

    std::unordered_map<node_ptr, node_ptr> oldToNew;
    // zipper together
    for (auto node : m_nodes) {
      auto new_node = graph.addNode(node->data);
      oldToNew[node] = new_node;
    }

    for (auto node : m_nodes) {
      auto new_node = oldToNew[node];
      for (auto child : node->children()) {
        auto new_child = oldToNew[child];
        new_node->adopt(new_child);
      }
    }

    return graph;
  }

  friend void swap(DirectedEdgeDataGraph &a,
                   DirectedEdgeDataGraph &b) noexcept {
    using std::swap;
    swap(a.m_nodes, b.m_nodes);
  }

  node_ptr operator[](size_t id) const { return m_nodes[id]; }

  template <class... Args> node_ptr addNode(Args &&...args) {
    auto node = createNode(std::forward<Args>(args)...);
    return node;
  }

  void deleteNode(node_ptr &node) {
    if (node == nullptr)
      return;
    node->disconnectFromAll();
    removeNode(node);
  }

  std::unique_ptr<Node> releaseNode(node_ptr &node) {
    if (node == nullptr)
      return {};
    node->disconnectFromAll();
    return removeNode(node);
  }

  node_store const &nodes() const { return m_nodes; }
  node_store &nodes() { return m_nodes; }

  bool isValidNode(node_ptr node) const {
    return utility::contains(node, m_nodes);
  }

  void clear() { cleanup(); }

  iterator begin() { return std::begin(m_nodes); }
  iterator end() { return std::end(m_nodes); }

  const_iterator begin() const { return std::begin(m_nodes); }
  const_iterator end() const { return std::end(m_nodes); }

  bool empty() const { return m_nodes.empty(); }
  size_t size() const { return m_nodes.size(); }

private: // functions
  template <class... Args> node_ptr createNode(Args &&...args) {
    // strong exception guaranteed (has enough space)
    m_nodes.reserve(size() + 1);
    m_nodes.emplace_back(new Node(std::forward<Args>(args)...));

    return m_nodes.back();
  }

  node_ptr createNode() {
    // strong exception guaranteed (has enough space)
    m_nodes.reserve(size() + 1);
    m_nodes.emplace_back(new Node{});

    return m_nodes.back();
  }

  std::unique_ptr<Node> removeNode(node_ptr &node) {
    assert(node->isDisconnected());

    std::unique_ptr<Node> owner{node};
    utility::remove(node, m_nodes);

    // invalidate pointer, todo wrap nodes as fatpointer structs?
    node = nullptr;

    return owner;
  }
  // needed as we are using raw pointers
  void cleanup() {
    for (auto node : m_nodes) {
      delete node;
    }
    m_nodes.clear();
  }

private:
  node_store m_nodes; // ownership
};

template <class T>
std::vector<Edge<typename DirectedGraph<T>::node_ptr>>
copyEdges(DirectedGraph<T> const &graph) {
  std::vector<Edge<typename DirectedGraph<T>::node_ptr>> edges;
  edges.reserve(graph.size() * 2); // dirty heuristic.... not great
  for (auto node : graph) {
    for (auto child : node->children()) {
      edges.emplace_back(node, child);
    }
  }
  return edges;
}

// Provide what 'mid' is for this graph
template <class T, class MidFunc>
DirectedGraph<T> midSubdivide(DirectedGraph<T> graph, MidFunc midFunc) {
  for (auto const &edge : copyEdges(graph)) {
    auto parent = edge.a;
    auto child = edge.b;

    auto mid = midFunc(parent->data, child->data);
    auto newNode = graph.addNode(mid);

    parent->orphan(child);
    parent->adopt(newNode);
    newNode->adopt(child);
  }

  return graph;
}

// Provide what 'mid' is for this graph
template <class T, class MidFunc>
void insitu_subdivideAtLength(DirectedGraph<T> &graph, MidFunc midFunc,
                              float length) {

  std::vector<Edge<typename DirectedGraph<T>::node_ptr>> edges;
  // collect edges
  for (auto node : graph) {
    for (auto child : node->children()) {

      if (distance(node->data.position, child->data.position) >= length) {
        edges.emplace_back(node, child);
      }
    }
  }

  // divide
  for (auto const &edge : edges) {
    auto parent = edge.a;
    auto child = edge.b;

    if (distance(parent->data.position, child->data.position) >= length) {
      auto mid = midFunc(parent->data, child->data);
      auto newNode = graph.addNode(mid);

      parent->orphan(child);
      parent->adopt(newNode);
      newNode->adopt(child);
    }
  }
}

template <class Node, class Func>
void propogateChangeToLeafs(Node node, Func func) {
  std::queue<Node> nodesToSee;
  nodesToSee.push(node);

  while (!nodesToSee.empty()) {
    node = nodesToSee.front();
    nodesToSee.pop();

    func(node);

    for (auto child : node->children())
      nodesToSee.push(child);
  }
}

using DirectedGraph3f = DirectedGraph<math::Vec3f>;

// remeshing operations

#if 0
template <class V, class E>
std::vector<typename DirectedEdgeDataGraph<V, E>::node_pt>
findUnionOfNeighbours(typename DirectedEdgeDataGraph<V, E>::node_ptr parent,
                      typename DirectedEdgeDataGraph<V, E>::node_ptr child) {
  std::vector<typename DirectedEdgeDataGraph<V, E>::node_ptr> neighs;
  neighs.reserve(2);

  for (auto pNeigh : parent->parents()) {
    for (auto cNeigh : child->parents()) {
      if (pNeigh == cNeigh) {
        neighs.push_back(pNeigh);
      }
    }
    for (auto cNeigh : child->children()) {
      if (pNeigh == cNeigh) {
        neighs.push_back(pNeigh);
      }
    }
  }

  if (neight.size() >= 2)
    return neighs;

  for (auto pNeigh : parent->children()) {
    for (auto cNeigh : child->parents()) {
      if (pNeigh == cNeigh) {
        neighs.push_back(pNeigh);
      }
    }
    for (auto cNeigh : child->children()) {
      if (pNeigh == cNeigh) {
        neighs.push_back(pNeigh);
      }
    }
  }

  return neighs;
}

template <class V, class E>
bool localFlipEdge(typename DirectedEdgeDataGraph<V, E>::node_ptr parent,
                   typename DirectedEdgeDataGraph<V, E>::node_ptr child) {
  auto neighs = findUnionOfNeighbours(parent, child);
  if (neighs.size() != 2)
    return false;

  auto edgeData = parent->edgeTo(child);
  parent->orphan(child);

  parent = neighs[0];
  child = neighs[1];

  parent->adopt(child);
  auto &e = parent->edgeTo(child);
  e = edgeData;
  return true;
}

template <class V, class E, class MidFunc>
bool localSplitEdge(DirectedEdgeDataGraph<V, E>::node_ptr parent,
                    DirectedEdgeDataGraph<V, E>::node_ptr child,
                    DirectedEdgeDataGraph<V, E> &graph, MidFunc midFunc) {
  auto neighs = findUnionOfNeighbours(parent, child);
  if (neighs.size() != 2)
    return false;

  auto edgeData = parent->edgeTo(child);
  parent->orphan(child);

  auto mid = graph.addNode();
  mid->data = midFunc(parent->data, child->data);

  parent->orphan(child);
  parent->adopt(mid);
  mid->adopt(child);

  parent->edgeTo(mid) = edgeData; // should be split?
  mid->edgeTo(child) = edgeData;  // should be split?

  for (auto neigh : neighs) {
    mid->adopt(neigh);
  }
  return true;
}
#endif

} // namespace geometry
