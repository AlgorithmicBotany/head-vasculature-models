#pragma once

#include <algorithm>
#include <functional>
#include <iosfwd>
#include <iterator>
#include <utility>
#include <vector>

namespace utility {

// [,) range
using index_interval = std::pair<uint32_t, uint32_t>;

std::ostream &operator<<(std::ostream &out, index_interval const &range);
std::istream &operator>>(std::istream &in, index_interval &range);

template <typename T>
index_interval intervalAppend(std::vector<T> const &source,
                              std::vector<T> &destination) {
  using namespace std;
  index_interval interval =
      make_pair(destination.size(), destination.size() + source.size());
  copy(begin(source), end(source), back_inserter(destination));

  return interval;
}

template <typename T>
void intervalCopy(index_interval range, std::vector<T> const &source,
                  std::vector<T> &destination) {
  using namespace std;
  copy(next(begin(source), range.first),  // [start, end)
       next(begin(source), range.second), //
       begin(destination));
}

// TODO oof no the best, but works
template <class S, class D>
index_interval intervalAppend(
    S const &source, D &destination,
    std::function<typename D::value_type(typename S::value_type)> packingFunc) {
  using namespace std;
  index_interval interval =
      make_pair(destination.size(), destination.size() + source.size());

  transform(begin(source), end(source), back_inserter(destination),
            packingFunc);

  return interval;
}

template <class S, class D>
void intervalCopy(
    index_interval range, S const &source, D &destination,
    std::function<typename D::value_type(typename S::value_type)> packingFunc) {

  using namespace std;
  transform(next(begin(source), range.first),  // [start, end)
            next(begin(source), range.second), //
            begin(destination), packingFunc);
}

template <class S, class D>
void intervalUpdate(index_interval range, S const &source, D &destination,
                    std::function<void(typename D::value_type &,
                                       typename S::value_type const &)>
                        updateFunc) {

  int j = 0;
  for (auto i = range.first; i < range.second; ++i) {
      updateFunc(destination[j], source[i]);
    ++j;
  }
}

} // namespace utility
