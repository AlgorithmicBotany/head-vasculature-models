/**
 * @author	Andrew Robert Owens
 * @details Organization: Biological Modeling and Visualization research group
 * University of Calgary, Calgary, AB, Canada
 *
 * Contact:	arowens [at] ucalgary.ca
 * @copyright Copyright (c) 2018 ___ALGORITHMIC_BOTANY___. All rights reserved.
 */

#pragma once

#include <vector>

#include "edge.h"
#include "triangle.h"
#include "vec3f.h"

namespace geometry {

class TriangleMesh {
public:
  using VertexID = uint32_t;
  using vertex_t = math::Vec3f;
  using triangle_t = geometry::Triangle<VertexID>;

  using triangles_t = std::vector<triangle_t>;
  using vertices_t = std::vector<vertex_t>;

public:
  TriangleMesh() = default;
  TriangleMesh(vertices_t vertices, triangles_t indexTriangles);

  void reloadVertices(vertices_t const &vertices);

  VertexID addVertex(vertex_t const &p);

  void addTriangle(triangle_t const &triangle);

  vertices_t const &vertices() const;

  vertices_t &vertices();

  triangles_t const &triangles() const;

  triangles_t &triangles();

  size_t vertexCount() const;

  size_t triangleCount() const;

  triangle_t const *triangleData() const;

  vertex_t const *vertexData() const;

  VertexID const *indiciesPointer() const;

  size_t indicesCount() const;

private:
  vertices_t m_vertices;
  triangles_t m_indexTriangles;
};

TriangleMesh subdivide(TriangleMesh const &mesh);

std::vector<math::Vec3f> calculateTriangleNormals(TriangleMesh const &mesh);

std::vector<math::Vec3f> calculateVertexNormals(TriangleMesh const &mesh);

std::vector<math::Vec3f>
calculateTriangleNormals(TriangleMesh::vertices_t const &vertices,
                         TriangleMesh::triangles_t const &indexTriangles);

std::vector<math::Vec3f>
calculateVertexNormals(TriangleMesh const &mesh,
                       std::vector<math::Vec3f> const &triangleNormals);

std::vector<math::Vec3f>
calculateVertexNormals(TriangleMesh::vertices_t const &vertices,
                       TriangleMesh::triangles_t const &indexTriangles,
                       std::vector<math::Vec3f> const &triangleNormals);

std::vector<geometry::Edge<TriangleMesh::VertexID>>
edges(TriangleMesh const &mesh);

TriangleMesh::triangle_t
addTriangle(TriangleMesh &mesh,
            geometry::Triangle<math::Vec3f> const &triangle);

geometry::Triangle<math::Vec3f>
triangleGeometry(TriangleMesh::triangle_t const &t, TriangleMesh const &mesh);

} // namespace geometry
