#pragma once

#include <algorithm>
#include <vector>

#include "vec3f.h"

namespace randutil {

void seed(unsigned int);

float uniformFloat();
float uniform(float a, float b);

template <typename T> T uniform(T lo, T hi);
template <> int uniform(int, int);

float gaussian(float sigma);
float gaussian(float sigma, float mu);

math::Vec3f gaussianVec3f(float sigma);
math::Vec3f gaussianVec3f(float sigma, float mu);

math::Vec2f gaussianVec2f(float sigma);
math::Vec2f gaussianVec2f(float sigma, float mu);

math::Vec3f uniformVec3f();
math::Vec3f uniform(math::Vec3f const &low, math::Vec3f const &high);

math::Vec3f uniformSphere();
math::Vec3f uniformHemisphere();
math::Vec3f uniformHemisphere(math::Vec3f const &normal,
                              math::Vec3f const &tangent);
math::Vec3f uniformCircle();
math::Vec3f uniformCircleAroundAxis(math::Vec3f const &axis);
math::Vec3f uniformCylinder(float height, float radius = 1.f);

math::Vec3f jitterDirection(math::Vec3f v, float probabilityOfJitter,
                            float strengthMin, float strengthMax);

template <typename T>
std::vector<T> uniformSamples(std::vector<T> const &cont, size_t sampleCount) {
  std::vector<T> samples;

  sampleCount = std::min(cont.size(), sampleCount);
  if (sampleCount == 0)
    return samples;

  samples.resize(sampleCount);
  std::generate_n(std::begin(samples), std::end(samples),
                  [=]() { return uniform(0, sampleCount - 1); });
  return samples;
}

} // namespace randutil
