#pragma once

#include <iosfwd>
#include <string>

// std for c++17+
//#include <optional>
// non std for c++11
#include "optional.hpp"

#include "cage_deformation_2D.h"

namespace modelling {

void insitu_readMeshCageFromBinaryStream(MeshCage &cage, std::istream &in);

//std::optional<MeshCageDeformation>
nonstd::optional<MeshCageDeformation>
readMeshCageDeformationFromBinaryFile(std::string const &filePath);

void insitu_readControurFieldGrowthFromFile(MeshCageDeformation &meshes,
                                            std::string const &binaryFilePath);

} // namespace modelling
