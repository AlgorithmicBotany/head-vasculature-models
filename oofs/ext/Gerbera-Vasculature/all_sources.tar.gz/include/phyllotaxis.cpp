//#include "modelling/phyllotaxis/phyllotaxis.h"
#include "phyllotaxis.h"

#include "math_utility.h"

namespace modelling {
namespace phyllotaxis {

std::vector<math::Vec3f> spiral(uint32_t count, float primordiaRadii) {
  std::vector<math::Vec3f> prims;
  prims.reserve(count);

  float currRadius = 0.25f;
  constexpr float dr = 0.001f;
  constexpr float angle = phyllotaxis::GoldenAngle;
  auto const xAxis = math::axis3::X;

  float r2 = primordiaRadii * primordiaRadii;

  for (uint32_t i = 0; i < count; ++i) {

    float area = float(M_PI) * r2 + 0.1f;
    float P = area / (float(M_PI) * 2.f);
    float r = 0;
    float accum = 0.f;
    while (accum < P) {
      r += dr;
      accum += (currRadius + r) * dr;
    }
    currRadius += r;

    auto o = rotateAroundZ(currRadius * xAxis, angle * i);
    prims.push_back(o);
  }

  return prims;
}

std::vector<math::Vec3f> unwrappedCylinder(uint32_t total, float cylinderRadius,
                                           float primordiaRadii) {
  std::vector<math::Vec3f> prims;
  prims.reserve(total);

  float currAngle = 0.f;
  constexpr float const divergenceAngle = GoldenAngle;
  float const circumference = 2.f * M_PI * cylinderRadius;

  for (int i = 0; i < total; ++i) {
    currAngle += divergenceAngle;
    currAngle = math::wrapToRange(currAngle, 0.f, 360.f);
    float x = (currAngle / 360.f) * circumference;
    float y = i * 2.f * M_PI * primordiaRadii / circumference;

    prims.push_back({x, y, 0.f});
  }

  return prims;
}

std::vector<math::Vec3f> cylinder(uint32_t total, float cylinderRadius,
                                  float primordiaRadii) {
  std::vector<math::Vec3f> prims;
  prims.reserve(total);

  float currAngle = 0.f;
  constexpr float const divergenceAngle = GoldenAngle;
  float const circumference = 2.f * M_PI * cylinderRadius;

  for (int i = 0; i < total; ++i) {
    currAngle += divergenceAngle;
    currAngle = math::wrapToRange(currAngle, 0.f, 360.f);

    auto p = math::rotateAroundY(
        {cylinderRadius,                                         // x
         i * 2.f * float(M_PI) * primordiaRadii / circumference, // y
         0.f},                                                   // z
        currAngle);

    prims.push_back(p);
  }

  return prims;
}
} // namespace phyllotaxis
} // namespace modelling
