#include "barycentric_coordinates.h"

#include "geometry_utility.h"
#include "vec3f.h"

namespace math {

float barycentricDeterminant(math::Vec2f const &u, math::Vec2f const &v) {
  // [ u v ] [s t]^T = [p]
  // determinate of matrix
  // (xu)(yv) - (yu)(xv)
  return u.x * v.y - v.x * u.y;
}

float norm(BarycentricCoordinates const &bary) {
  return math::norm(math::Vec3f(bary.u, bary.v, bary.w));
}

BarycentricCoordinates barycentricCoordinates(math::Vec2f const &u,
                                              math::Vec2f const &v,
                                              math::Vec2f const &p) {
  BarycentricCoordinates bcCoord;

  // solve system (via Cramer's rule)
  // [ u v ] [uValue vValue]^T = [p]
  // determinate of matrix
  // (xu)(yv) - (yu)(xv)

  float denom = barycentricDeterminant(u, v); // constant per triangle

  // det[ p v ] / det [ u v ]
  bcCoord.u = (v.y * p.x - v.x * p.y) / denom;
  // det[ u p ] / det [ u v ]
  bcCoord.v = (u.x * p.y - u.y * p.x) / denom;

  bcCoord.w = 1.f - (bcCoord.u + bcCoord.v);

  return bcCoord;
}

float barycentricDeterminant(math::Vec2f const &a, math::Vec2f const &b,
                             math::Vec2f const &c) {
  return barycentricDeterminant(a - c, b - c);
}

BarycentricCoordinates barycentricCoordinates(math::Vec2f const &a,
                                              math::Vec2f const &b,
                                              math::Vec2f const &c,
                                              math::Vec2f const &p) {
  return barycentricCoordinates(a - c, b - c, p - c);
}

bool isConvex(BarycentricCoordinates const &bary) {
  return !(bary.u < 0.f || bary.v < 0.f || bary.u + bary.v > 1.f);
}

bool isConvex(BarycentricCoordinates const &bary, float tol) {
  return !(bary.u < -tol || bary.v < -tol || bary.u + bary.v > 1.f + tol);
}

bool isInsideTriangle(math::Vec2f const &a, math::Vec2f const &b,
                      math::Vec2f const &c, math::Vec2f const &p) {
  return isConvex(barycentricCoordinates(a, b, c, p));
}

bool isInsideTriangle(math::Vec2f const &a, math::Vec2f const &b,
                      math::Vec2f const &c, math::Vec2f const &p, float tol) {
  return isConvex(barycentricCoordinates(a, b, c, p), tol);
}

#if 0
std::pair<bool, math::Vec2f> insideOrClosestPoint(math::Vec2f const &a,
                                                  math::Vec2f const &b,
                                                  math::Vec2f const &c,
                                                  math::Vec2f const &p) {
  auto pa = p - a;
  auto ba = b - a;
  auto ca = c - a;

  auto caPerp = math::perpendicularTo(ca);
  auto paPerp = math::perpendicularTo(pa);

  BarycentricCoordinates coords;
  coords.u = -(ca * paPerp) / (ba * caPerp);
  coords.v = (ba * paPerp) / (ba * caPerp);
  coords.w = 1.f - (coords.u + coords.v);

  if (isInside(coords))
    return {true, p};

  auto cb = geometry::closestToLineSegment(b, c, p);
  ba = geometry::closestToLineSegment(a, b, p);
  ca = geometry::closestToLineSegment(a, c, p);

  auto cbDist = math::distance(cb, p);
  auto baDist = math::distance(ba, p);
  auto caDist = math::distance(ca, p);

  if (cbDist < baDist) {
    if (cbDist < caDist) {
      return {false, cb};
    } else {
      return {false, ca};
    }
  } else {
    if (baDist < caDist) {
      return {false, ba};
    } else {
      return {false, ca};
    }
  }
}

std::pair<bool, BarycentricCoordinates> insideOrClosestBarycentricCoordinates(
    math::Vec2f const &a, math::Vec2f const &b, math::Vec2f const &c,
    math::Vec2f const &p) {

  auto pa = p - a;
  auto ba = b - a;
  auto ca = c - a;

  auto caPerp = math::perpendicularTo(ca);
  auto paPerp = math::perpendicularTo(pa);

  BarycentricCoordinates bary;
  bary.u = -(ca * paPerp) / (ba * caPerp);
  bary.v = (ba * paPerp) / (ba * caPerp);
  bary.w = 1.f - (bary.u + bary.v);

  if (isInside(bary))
    return {true, bary};

  auto cbPoint = geometry::closestToLineSegment(b, c, p);
  auto baPoint = geometry::closestToLineSegment(a, b, p);
  auto caPoint = geometry::closestToLineSegment(a, c, p);

  auto cbDist = math::distance(cbPoint, p);
  auto baDist = math::distance(baPoint, p);
  auto caDist = math::distance(caPoint, p);

  if (cbDist < baDist) {
    if (cbDist < caDist) {
      auto t = ((cbPoint - b) * (c - b)) / ((c - b) * (c - b));
      BarycentricCoordinates cbBary{1.f - t, t, 0.f};
      return {false, cbBary};
    } else {
      auto t = ((caPoint - a) * ca) / (ca * ca);
      BarycentricCoordinates caBary{0, t, 1.f - t};
      return {false, caBary};
    }
  } else {
    if (baDist < caDist) {
      auto t = ((baPoint - a) * ba) / (ba * ba);
      BarycentricCoordinates baBary{1.f - t, 0.f, t};
      return {false, baBary};
    } else {
      auto t = ((caPoint - a) * ca) / (ca * ca);
      BarycentricCoordinates caBary{0, t, 1.f - t};
      return {false, caBary};
    }
  }
}
#endif

} // namespace math
