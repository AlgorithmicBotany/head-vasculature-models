#pragma once

#include <utility>

#include "vec2f.h"

namespace math {

struct BarycentricCoordinates {
  float u, v, w;
};

float norm(BarycentricCoordinates const &bary);

float barycentricDeterminant(math::Vec2f const &u, math::Vec2f const &v);

BarycentricCoordinates barycentricCoordinates(math::Vec2f const &u,
                                              math::Vec2f const &v,
                                              math::Vec2f const &p);

float barycentricDeterminant(math::Vec2f const &a, math::Vec2f const &b,
                             math::Vec2f const &c);

BarycentricCoordinates barycentricCoordinates(math::Vec2f const &a,
                                              math::Vec2f const &b,
                                              math::Vec2f const &c,
                                              math::Vec2f const &p);

bool isConvex(BarycentricCoordinates const &bary);
bool isConvex(BarycentricCoordinates const &bary, float tolerance);

bool isInsideTriangle(math::Vec2f const &a, math::Vec2f const &b,
                      math::Vec2f const &c, math::Vec2f const &p);
bool isInsideTriangle(math::Vec2f const &a, math::Vec2f const &b,
                      math::Vec2f const &c, math::Vec2f const &p,
                      float tolerance);

template <class T>
T blend(T const &U, T const &V, T const &W,
        BarycentricCoordinates const &bary) {
  return U * bary.u + V * bary.v + W * bary.w;
}

#if 0
std::pair<bool, math::Vec2f> insideOrClosestPoint(math::Vec2f const &a,
                                                  math::Vec2f const &b,
                                                  math::Vec2f const &c,
                                                  math::Vec2f const &p);

std::pair<bool, BarycentricCoordinates> insideOrClosestBarycentricCoordinates(
    math::Vec2f const &a, math::Vec2f const &b, math::Vec2f const &c,
    math::Vec2f const &p);

#endif

} // namespace math
