#pragma once

#include <iosfwd>

#include "vec3f.h"

namespace math {

// struct declaration
struct Vec4f {
  union {
    struct {
      float x;
      float y;
      float z;
      float w;
    };
    float m_coord[4];
  };

  // Vec4f() = default; // TODO: clang issue from above
  Vec4f();
  Vec4f(float x, float y, float z, float w);

  explicit operator Vec3f();

  /*
   * Mutating member functions
   */
  Vec4f &operator+=(Vec4f const &rhs);
  Vec4f &operator-=(Vec4f const &rhs);
  Vec4f &operator*=(float rhs);
  Vec4f &operator/=(float rhs);

  Vec4f &operator=(Vec4f const &rhs) = default;

  float &operator[](size_t id);
  float const &operator[](size_t id) const;

  float *data();
  float const *data() const;

  Vec4f &normalize();

  void zero();
};

namespace vec4f {
Vec4f from(Vec3f const &v, float homogenous);
}

// Free function declarations
Vec4f operator+(Vec4f const &a, Vec4f const &b);
Vec4f operator-(Vec4f const &a, Vec4f const &b);
Vec4f operator*(float s, Vec4f v);
Vec4f operator*(Vec4f v, float s);
Vec4f operator/(Vec4f v, float s);
Vec4f operator-(Vec4f v);

float norm(Vec4f const &v);
float normSquared(Vec4f const &v);
Vec4f normalized(Vec4f v);

std::istream &operator>>(std::istream &in, Vec4f &v);
std::ostream &operator<<(std::ostream &out, Vec4f const &v);

} // namespace math
