#include "vec4f.h"

#include <cmath>
#include <iostream>

namespace math {

// Member function interface
// TODO added to appese clang: initialized {0,0,0} bug
Vec4f::Vec4f() : x(0.f), y(0.f), z(0.f), w(0.f) {}

Vec4f::Vec4f(float x, float y, float z, float w) : x(x), y(y), z(z), w(w) {}

Vec4f::operator Vec3f() { return {x, y, z}; }

Vec4f &Vec4f::operator+=(Vec4f const &rhs) {
  x += rhs.x;
  y += rhs.y;
  z += rhs.z;
  w += rhs.z;
  return *this;
}
Vec4f &Vec4f::operator-=(Vec4f const &rhs) {
  x -= rhs.x;
  y -= rhs.y;
  z -= rhs.z;
  w -= rhs.z;
  return *this;
}

Vec4f &Vec4f::operator*=(float rhs) {
  x *= rhs;
  y *= rhs;
  z *= rhs;
  w *= rhs;
  return *this;
}

Vec4f &Vec4f::operator/=(float rhs) {
  x /= rhs;
  y /= rhs;
  z /= rhs;
  w /= rhs;
  return *this;
}

float &Vec4f::operator[](size_t id) { return m_coord[id]; }

float const &Vec4f::operator[](size_t id) const { return m_coord[id]; }

float *Vec4f::data() { return &m_coord[0]; }

float const *Vec4f::data() const { return &m_coord[0]; }

Vec4f &Vec4f::normalize() {
  float l = norm(*this);
  return (*this) /= l;
}

void Vec4f::zero() {
  x = 0.f;
  y = 0.f;
  z = 0.f;
  w = 0.f;
}

// Free function

namespace vec4f {
Vec4f from(Vec3f const &v, float homogeneous) {
  return {v.x, v.y, v.z, homogeneous};
}
} // namespace vec4f

/*
 * Vector-Vector Addition/ Subtraction
 */
Vec4f operator+(Vec4f const &a, Vec4f const &b) {
  return Vec4f(a.x + b.x, //
               a.y + b.y, //
               a.z + b.z, //
               a.w + b.w);
}
Vec4f operator-(Vec4f const &a, Vec4f const &b) {
  return Vec4f(a.x - b.x, //
               a.y - b.y, //
               a.z - b.z, //
               a.w - b.w);
}

/*
 * Scalar-Vector Multiplication/Division
 */
Vec4f operator*(float s, Vec4f v) {
  v.x *= s;
  v.y *= s;
  v.z *= s;
  v.w *= s;
  return v;
}
Vec4f operator*(Vec4f v, float s) { return s * v; }

Vec4f operator/(Vec4f v, float s) {
  v.x /= s;
  v.y /= s;
  v.z /= s;
  v.w /= s;
  return v;
}

/*
 * Negation of vector
 * -v = (-1.f) * v
 */
Vec4f operator-(Vec4f v) {
  v.x = -v.x;
  v.y = -v.y;
  v.z = -v.z;
  v.x = -v.w;
  return v;
}

/*
 * Vector norm (length)
 */
float norm(Vec4f const &v) {
  return std::sqrt(v.x * v.x + v.y * v.y + v.z * v.z);
}
float normSquared(Vec4f const &v) { return v.x * v.x + v.y * v.y + v.z * v.z; }

/*
 * Normalized Vector
 */
Vec4f normalized(Vec4f v) {
  float l = norm(v);
  return v /= l;
}

std::ostream &operator<<(std::ostream &out, Vec4f const &v) {
  return out << v.x << " " << v.y << " " << v.z;
}

std::istream &operator>>(std::istream &in, Vec4f &v) {
  return in >> v.x >> v.y >> v.z;
}

} // namespace math
