#pragma once

#include <vector>

namespace geometry {

template <typename T, class Distance>
std::vector<T> calculateRelative(T const &p, std::vector<T> const &nodes,
                                 Distance distance) {

  std::vector<T> out;

  for (int i = 0; i < nodes.size(); ++i) {
    auto node_i = nodes[i];

    /*   if (node_i == p)
         continue;*/

    auto s_i = distance(p, node_i);

    if (s_i < 1e-5)
      continue;

    bool isRelative = true;

    for (int j = 0; j < nodes.size(); ++j) {
      if (j == i)
        continue;

      auto node_j = nodes[j];

      /* if (node_j == p)
         continue;*/

      auto s_j = distance(p, node_j);

      if (s_j < 1e-5)
        continue;

      auto i_j = distance(node_i, node_j);

      if (s_i - std::max(s_j, i_j) >= 0.f) {
        isRelative = false;
        break;
      }
    }

    // is a relative
    if (isRelative)
      out.push_back(node_i);
  }

  return out;
}

} // namespace geometry
