/**
 * @file	trianglemesh.cpp
 * @author	Andrew Robert Owens
 * @date 	2018-2-24.
 * @brief	CollisionExample: trianglemesh.cpp
 * @details Organization: Biological Modeling and Visualization research group
 * University of Calgary, Calgary, AB, Canada
 *
 * Contact:	arowens [at] ucalgary.ca
 * @copyright Copyright (c) 2018 ___ALGORITHMIC_BOTANY___. All rights reserved.
 *
 * @brief
 */

#include "triangle_mesh.h"

#include <algorithm>
#include <cassert>
#include <map>

#include "ordered_tuple.h"

using namespace math;

namespace geometry {

TriangleMesh::TriangleMesh(vertices_t vertices, triangles_t indexTriangles)
    : m_vertices(vertices), m_indexTriangles(indexTriangles) {}

void TriangleMesh::reloadVertices(TriangleMesh::vertices_t const &vertices) {
  assert(m_vertices.size() == vertices.size());
  std::copy_n(std::begin(vertices), vertices.size(), std::begin(m_vertices));
}

TriangleMesh::VertexID TriangleMesh::addVertex(vertex_t const &p) {
  VertexID id = vertexCount();
  vertices().push_back(p);
  return id;
}

void TriangleMesh::addTriangle(triangle_t const &triangle) {
  triangles().push_back(triangle);
}

TriangleMesh::vertices_t const &TriangleMesh::vertices() const {
  return m_vertices;
}

TriangleMesh::vertices_t &TriangleMesh::vertices() { return m_vertices; }

TriangleMesh::triangles_t const &TriangleMesh::triangles() const {
  return m_indexTriangles;
}

TriangleMesh::triangles_t &TriangleMesh::triangles() {
  return m_indexTriangles;
}

size_t TriangleMesh::vertexCount() const { return m_vertices.size(); }

size_t TriangleMesh::triangleCount() const { return m_indexTriangles.size(); }

TriangleMesh::triangle_t const *TriangleMesh::triangleData() const {
  return m_indexTriangles.data();
}

TriangleMesh::vertex_t const *TriangleMesh::vertexData() const {
  return m_vertices.data();
}

TriangleMesh::VertexID const *TriangleMesh::indiciesPointer() const {
  return (VertexID *)(triangleData());
}

size_t TriangleMesh::indicesCount() const { return triangleCount() * 3; }

// FREE FUNCTTIONS

TriangleMesh subdivide(TriangleMesh const &mesh) {

  TriangleMesh meshOut;
  meshOut.triangles().reserve(mesh.triangleCount() * 4);

  using edge = math::Tuple<TriangleMesh::VertexID, 2>;

  std::map<edge, TriangleMesh::VertexID> edgeToMid;

  // same order
  meshOut.vertices() = mesh.vertices();

  auto getMidID = [&](edge const &eAB, math::Vec3f const &a,
                      math::Vec3f const &b) {
    auto iter = edgeToMid.find(eAB);

    if (iter != edgeToMid.end())
      return iter->second;

    auto midID = meshOut.addVertex(math::mid(a, b));
    edgeToMid.insert(iter, std::make_pair(eAB, midID));
    return midID;
  };

  for (auto const &t : mesh.triangles()) {
    auto t_Geom = triangleGeometry(t, mesh);

    auto ab = math::makeOrdered_tuple(t.a, t.b);
    auto bc = math::makeOrdered_tuple(t.b, t.c);
    auto ca = math::makeOrdered_tuple(t.c, t.a);

    auto abID = getMidID(ab, t_Geom.a, t_Geom.b);
    auto bcID = getMidID(bc, t_Geom.b, t_Geom.c);
    auto caID = getMidID(ca, t_Geom.c, t_Geom.a);

    meshOut.addTriangle({t.a, abID, caID});
    meshOut.addTriangle({t.b, bcID, abID});
    meshOut.addTriangle({t.c, caID, bcID});
    meshOut.addTriangle({abID, bcID, caID});
  }

  return meshOut;
}

std::vector<Vec3f> calculateTriangleNormals(TriangleMesh const &mesh) {
  return calculateTriangleNormals(mesh.vertices(), mesh.triangles());
}

std::vector<math::Vec3f> calculateVertexNormals(TriangleMesh const &mesh) {
  return calculateVertexNormals(mesh, calculateTriangleNormals(mesh));
}

std::vector<Vec3f>
calculateTriangleNormals(TriangleMesh::vertices_t const &vertices,
                         TriangleMesh::triangles_t const &triangles) {
  std::vector<Vec3f> tmp;
  tmp.reserve(triangles.size());

  for (auto const &triangle : triangles) {
    auto const &a = vertices[triangle.a];
    auto const &b = vertices[triangle.b];
    auto const &c = vertices[triangle.c];

    // take cross product and normalize
    // assumes counter clockwise winding a-b-c
    tmp.emplace_back(normalized((b - a) ^ (c - a)));
  }

  return tmp;
}

std::vector<Vec3f>
calculateVertexNormals(TriangleMesh const &mesh,
                       std::vector<Vec3f> const &triangleNormals) {
  return calculateVertexNormals(mesh.vertices(), mesh.triangles(),
                                triangleNormals);
}

std::vector<Vec3f>
calculateVertexNormals(TriangleMesh::vertices_t const &vertices,
                       TriangleMesh::triangles_t const &triangles,
                       std::vector<Vec3f> const &triangleNormals) {
  assert(triangles.size() == triangleNormals.size());

  std::vector<Vec3f> tmp;
  // allocate and preinitalize to zero for following normal accumulation
  tmp.resize(vertices.size(), Vec3f(0.f, 0.f, 0.f));

  for (int tID = 0; tID < triangles.size(); ++tID) {
    auto const &t = triangles[tID];
    auto const &n = triangleNormals[tID];

    // accumulate face normal for each vertex
    tmp[t.a] += n;
    tmp[t.b] += n;
    tmp[t.c] += n;
  }

  // normalize (average) normals
  for (auto &n : tmp) {
    n.normalize();
  }

  return tmp;
}

std::vector<geometry::Edge<TriangleMesh::VertexID>>
edges(TriangleMesh const &mesh) {

  std::vector<geometry::Edge<TriangleMesh::VertexID>> tmp;
  tmp.reserve(3.f / 2.f * mesh.triangleCount()); // Euler: assuming V- E + F ~ 0

  auto testForUniqueEdge = [&](TriangleMesh::VertexID aID,
                               TriangleMesh::VertexID bID) {
    auto edgeIndices = math::makeOrdered_tuple(aID, bID);
    auto iter = std::find_if(
        std::begin(tmp), std::end(tmp),
        [edgeIndices](geometry::Edge<TriangleMesh::VertexID> const &edge) {
          return edgeIndices == math::makeOrdered_tuple(edge.a, edge.b);
        });
    return iter == std::end(tmp);
  };

  for (auto const &t : mesh.triangles()) {
    if (testForUniqueEdge(t.a, t.b))
      tmp.push_back({t.a, t.b});

    if (testForUniqueEdge(t.b, t.c))
      tmp.push_back({t.b, t.c});

    if (testForUniqueEdge(t.c, t.a))
      tmp.push_back({t.c, t.a});
  }

  return tmp;
}

TriangleMesh::triangle_t
addTriangle(TriangleMesh &mesh,
            geometry::Triangle<math::Vec3f> const &triangle) {
  auto aID = mesh.addVertex(triangle.a);
  auto bID = mesh.addVertex(triangle.b);
  auto cID = mesh.addVertex(triangle.c);

  TriangleMesh::triangle_t t{aID, bID, cID};
  mesh.addTriangle(t);
  return t;
}

geometry::Triangle<math::Vec3f>
triangleGeometry(TriangleMesh::triangle_t const &t, TriangleMesh const &mesh) {
  auto const &v = mesh.vertices();
  return {v[t.a], v[t.b], v[t.c]};
}
} // namespace geometry
