#pragma once

#include "vec3f.h"
#include "vec3i.h"

#include "vec2f.h"
#include "vec2i.h"

#include "mat3f.h"
#include "mat4f.h"

namespace math {

// namespace detail {
// template <typename Alias> struct VecBase { using type = Alias; };
// template <int N, typename T> struct VecAlias final {};
//
// template <> struct VecAlias<2, int> final : VecBase<math::Vec2i> {};
// template <> struct VecAlias<2, float> final : VecBase<math::Vec2f> {};
// template <> struct VecAlias<3, int> final : VecBase<math::Vec3i> {};
// template <> struct VecAlias<3, float> final : VecBase<math::Vec3f> {};
//} // namespace detail

namespace detail {
template <int Dim, typename T> struct VecAlias;

template <> struct VecAlias<2, int> final { using type = math::Vec2i; };
template <> struct VecAlias<2, float> final { using type = math::Vec2f; };
template <> struct VecAlias<3, int> final { using type = math::Vec3i; };
template <> struct VecAlias<3, float> final { using type = math::Vec3f; };

} // namespace detail

template <int N, typename T> using vec = typename detail::VecAlias<N, T>::type;

math::Vec3f clamp(math::Vec3f const &a, math::Vec3f const &lo,
                  math::Vec3f const hi);

math::Vec2i clamp(math::Vec2i const &a, math::Vec2i const &lo,
                  math::Vec2i const hi);

math::Mat3f arbitraryOrientationFrom(math::Vec3f v);

math::Mat4f orientationToAffine(math::Mat3f const &m);

Vec4f toHomogeneousCoordinate(Vec3f const &ndc, float w);

Vec4f perspectiveDivide(Vec4f homogeneousCoordinate);

} // namespace math
