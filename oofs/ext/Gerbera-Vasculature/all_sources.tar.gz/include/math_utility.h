//
//  utility.h
//  CollisionExample
//
//  Created by Andrew Owens on 2018-02-21.
//  Copyright (c) 2018 ___ALGORITHMIC_BOTANY___. All rights reserved.
//

#pragma once

#include <type_traits>

namespace math {

template <typename T> constexpr T maxValue();

template <typename T> constexpr T minValue();

/**
 * Type-safe and precision appropriate conversion from radians to degrees
 * TODO: variable template C++14
 */
template <typename Float> constexpr Float radianToDegree(Float radian);

/**
 * Type-safe and precision appropriate conversion from degrees to radians
 * TODO: variable template C++14
 */
template <typename Float> constexpr Float degreeToRadian(Float degree);

/**
 * Compares floating point (float, double, long double) to zero to within a
 * default epsilon (std::numeric_limits<Float>::epsilon())
 */
template <typename Float> constexpr bool isZero(Float x);

/**
 * Compares floating point (float, double, long double) to zero to within a user
 * defined epsilon
 */
template <typename Float> constexpr bool isZero(Float x, Float epsilon);

/**
 * Return the sign of the value: sgn(val)
 */
template <typename Signed> constexpr int sgn(Signed val);

/**
 * Returns the absolute value of a signed value
 */
template <typename Signed> constexpr Signed abs(const Signed &value);

/**
 * Retruns minimum of two arguments, returning the first argument upon
 * equivalence.
 */
template <typename Type>
constexpr Type const &minimum(Type const &a, Type const &b);

/**
 * Retruns minimum of two arguments using a custom comparitor, returning the
 * first argument upon equivalence.
 */
template <typename Type, typename Comp>
constexpr Type const &minimum(Type const &a, Type const &b, Comp comp);

/**
 * Retruns minimum of a variadic argument list, returning the first argument
 * upon equivalence.
 */
template <typename T, typename... Args>
constexpr T const &minimum(T const &a, T const &b, Args... args);

/**
 * Retruns minimum of a variadic argument list using a custom comparitor,
 * returning the first argument upon equivalence.
 */
template <typename T, typename... Args, typename Comp>
constexpr T const &minimum(T const &a, T const &b, Args... args, Comp comp);

/**
 * Retruns maximum of two arguments, returning the second argument upon
 * equivalence.
 */
template <typename Type>
constexpr Type const &maximum(Type const &a, Type const &b);

/**
 * Retruns maximum of two arguments using a custom comparitor, returning the
 * second argument upon equivalence.
 */
template <typename Type, typename Comp>
constexpr Type const &maximum(Type const &a, Type const &b, Comp comp);

/**
 * Retruns maximum of a variadic argument list, returning the second argument
 * upon equivalence.
 */
template <typename T, typename... Args>
constexpr T const &maximum(T const &a, T const &b, Args... args);

/**
 * Retruns maximum of a variadic argument list using a custom comparitor,
 * returning the second argument upon equivalence.
 */
template <typename T, typename... Args, typename Comp>
constexpr T const &maximum(T const &a, T const &b, Args... args, Comp comp);

/**
 * Clamp generic type
 */
template <class T>
constexpr T const &clamp(const T &v, const T &lo, const T &hi);

/**
 * Clamp generic types with custum comparitor
 */
template <class T, class Compare>
constexpr T const &clamp(const T &v, const T &lo, const T &hi, Compare comp);

/**
 *Returns if in interval
 */
template <class T>
constexpr bool in_LeftClosed_Interval(const T &v, const T &lo, const T &hi);

/**
 * Returns if in interval
 */
template <class T>
constexpr bool in_Closed_Interval(const T &v, const T &lo, const T &hi);

template <typename T> T lerp(T const &a, T const &b, float t) {
  return a * (1.f - t) + b * t;
}

template <typename T> T mid(T const &a, T const &b) { return (a + b) * 0.5f; }

template <class T, class R>
R map(T const &v, T const &a_lo, T const &a_hi, R const &b_lo, R const &b_hi) {
  float t = float(v - a_lo) / float(a_hi - a_lo);
  return t * (b_hi - b_lo) + b_lo;
}

template <class T> T mapToUnitInterval(T const &v, T const &lo, T const &hi) {
  return (v - lo) / (hi - lo);
}

/**
 *	Fraciontal part of argument
 *	https://stackoverflow.com/questions/12367071/how-do-i-initialize-the-t-variables-in-a-fast-voxel-traversal-algorithm-for-ray
 */

float fractional(float x, int sgn);

float wrapToMax(float x, float m);
float wrapToRange(float x, float a, float b);

template <typename Container, typename T = typename Container::value_type>
T arithmeticMean(Container const &container);

template <class T> T arithmeticMean(T const &a, T const &b, T const c) {
  return (a + b + c) * (1. / 3.);
}

template <typename T> constexpr T maximum();

float gaussian(float phi, float sigma);
float gaussian_Derivative1(float phi, float sigma);
float gaussian_Derivative2(float phi, float sigma);

float gaussian(float x, float mu, float sigma);
float gaussian_Derivative1(float x, float mu, float sigma);
float gaussian_Derivative2(float x, float mu, float sigma);

float wyvillFallOff(float x, float radius);
float wyvillFallOff_Derivative1(float x, float radius);
float wyvillFallOff_Derivative2(float x, float radius);

float normalizedBump(float x, float radius, int squareness);

float smoothstep(float x, float edge0, float edge1);

} // namespace math

#include "math_utility.tpp"
